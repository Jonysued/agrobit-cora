import { lazy, Suspense } from 'react';
import LoadingState from '@/components/LoadingState';
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import AuthCallback from '@/pages/AuthCallback';
const AppLayout = lazy(() => import('@/components/AppLayout'));
import { FarmProvider } from '@/lib/FarmContext';
const MapPage = lazy(() => import('@/pages/MapPage'));
const Dashboard = lazy(() => import('@/pages/Dashboard'));
const MobileMore = lazy(() => import('@/pages/MobileMore'));
const MobileWeather = lazy(() => import('@/pages/MobileWeather'));
const Lots = lazy(() => import('@/pages/Lots'));
const LotDetail = lazy(() => import('@/pages/LotDetail'));
const Irrigation = lazy(() => import('@/pages/Irrigation'));
const Documents = lazy(() => import('@/pages/Documents'));
const Settings = lazy(() => import('@/pages/Settings'));
const WaterEnergyLot = lazy(() => import('@/pages/WaterEnergyLot'));
const WaterEnergyEnergy = lazy(() => import('@/pages/WaterEnergyEnergy'));
const WaterEnergySoilPoint = lazy(() => import('@/pages/WaterEnergySoilPoint'));

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Keep the local authentication screens reachable while the app is protected.
  if (authError) {
    const authPaths = ['/login', '/register', '/forgot-password', '/reset-password', '/auth/callback'];
    const isAuthScreen = authPaths.includes(window.location.pathname);
    if (authError.type === 'user_not_registered' && !isAuthScreen) {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required' && !isAuthScreen) {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Suspense fallback={<LoadingState />} >
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/auth/callback" element={<AuthCallback />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<FarmProvider><AppLayout /></FarmProvider>}>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/mapa" element={<MapPage />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/mas" element={<MobileMore />} />
          <Route path="/clima" element={<MobileWeather />} />
          <Route path="/lotes" element={<Lots />} />
          <Route path="/lotes/:id" element={<LotDetail />} />
          <Route path="/produccion" element={<Navigate to="/configuracion?tab=produccion" replace />} />
          <Route path="/riego" element={<Irrigation />} />
          <Route path="/water-energy" element={<Navigate to="/water-energy/energia" replace />} />
          <Route path="/water-energy/riegos" element={<Navigate to="/riego?tab=monitoreo" replace />} />
          <Route path="/water-energy/energia" element={<WaterEnergyEnergy />} />
          <Route path="/water-energy/sensores" element={<Navigate to="/riego?tab=sensores" replace />} />
          <Route path="/water-energy/sensores/:probeId" element={<WaterEnergySoilPoint />} />
          <Route path="/water-energy/configuracion" element={<Navigate to="/configuracion?tab=water-energy" replace />} />
          <Route path="/water-energy/lote/:lotId" element={<WaterEnergyLot />} />
          <Route path="/documentos" element={<Documents />} />
          <Route path="/configuracion" element={<Settings />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
    </Suspense>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App
