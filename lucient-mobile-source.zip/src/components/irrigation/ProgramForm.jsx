import React,{useState} from 'react';
import { backend } from '@/api/backendClient';
import { Droplets, Plus, Pencil, X } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import { PORTION_LABELS } from '@/lib/irrigationTurnos';
import { turnMembers, wellProgramName, businessDay } from '@/services/irrigation/planning';
import { densityOf } from '@/lib/farmCalculations';
import { es } from 'date-fns/locale';
import { durationMinutes, programOverlaps } from '@/services/irrigation/programTiming';
import { useIsMobile } from '@/hooks/use-mobile';

const STATUSES=['Programado','Activo','Pausado','Finalizado'];
const isoDate=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const toDate=s=>s?new Date(`${s}T00:00:00`):null;
const blank=()=>({date:null,start_time:'06:00',end_time:'',end_date:'',well:'',turno:'',mm:'',status:'Programado',notes:''});
const toMin=t=>{const [h,m]=t.split(':').map(Number);return h*60+m;};
const endDefault=d=>{if(!d?.start_time||d?.duration_min==null)return '';const e=(toMin(d.start_time)+Number(d.duration_min))%1440;return `${String(Math.floor(e/60)).padStart(2,'0')}:${String(e%60).padStart(2,'0')}`;};

export default function ProgramForm({lots,designs=[],programs=[],devices=[],edit,onSaved,onCancel}){
  const mobile=useIsMobile();
  const [form,setForm]=useState(edit?{
    date:toDate(edit.date),start_time:edit.start_time||'06:00',end_time:endDefault(edit),end_date:businessDay(Date.parse(`${edit.date}T${edit.start_time || '06:00'}-03:00`)+Number(edit.duration_min || 0)*60000),well:edit.well||'',turno:edit.turno||'',status:edit.status||'Programado',notes:edit.notes||''
  }:blank());
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const wells=devices.filter(d=>d.kind==='well');
  const WELLS=wells.map(wellProgramName);
  const selectedWell=wells.find(w=>wellProgramName(w)===form.well);
  const turnos=[...new Set(devices.filter(v=>v.kind==='valve'&&v.parent_well_id===selectedWell?.id&&v.turno?.trim()).map(v=>v.turno.trim().toUpperCase()))].sort().map(value=>({value,lots:turnMembers(devices,selectedWell.id,value).map(m=>({lot:lots.find(l=>l.id===m.lotId)?.name||m.lotId,portion:[...m.portions].join(' + ')}))}));
  const selectedTurno=turnos.find(t=>t.value===form.turno);
  const items=selectedTurno?turnMembers(devices,selectedWell.id,form.turno).map(m=>({code:lots.find(l=>l.id===m.lotId)?.name||m.lotId,portion:[...m.portions].join(' + '),factor:m.factor,lotRec:lots.find(l=>l.id===m.lotId)})):[];
  const hours=durationMinutes(form.start_time,form.end_time,form.date?isoDate(form.date):null,form.end_date)/60;
  const busyOverlap=(p,well=form.well)=>programOverlaps(p,{...form,well,date:form.date?isoDate(form.date):null},edit?.id);
  const busyWell=(programs||[]).find(p=>p.well===form.well&&busyOverlap(p));
  const conflict=!!busyWell;
  const endTime=p=>{const [h,m]=p.start_time.split(':').map(Number);const e=(h*60+m+Number(p.duration_min))%1440;return `${String(Math.floor(e/60)).padStart(2,'0')}:${String(e%60).padStart(2,'0')}`;};
  const set=(k,v)=>setForm(f=>({...f,[k]:v}));
  const submit=async e=>{
    e.preventDefault();
    if(busy||conflict||!form.date||!form.well||!hours||!selectedTurno||!items.length||items.some(i=>!i.lotRec))return;
    setBusy(true);setError('');
    const mins=hours*60;
    const itemsOut=selectedTurno?items.map(({code,portion,lotRec,factor})=>({lot_id:lotRec?.id||null,lot_name:code,portion:PORTION_LABELS[portion]||portion||'Completo',factor})):(edit?.items||[]);
    const lotIds=selectedTurno?[...new Set(itemsOut.map(i=>i.lot_id).filter(Boolean))]:[...(edit?.lot_ids||[])];
    const payload={lot_ids:lotIds,items:itemsOut,date:isoDate(form.date),start_time:form.start_time,duration_min:mins,well:form.well,turno:form.turno||undefined,status:form.status,notes:form.notes};
    try {
      if(edit) await backend.entities.IrrigationProgram.update(edit.id,payload);
      else await backend.entities.IrrigationProgram.create(payload);
    } catch(err) { setError(err.message||'No se pudo guardar el programa. Volvé a intentar.');return; }
    finally { setBusy(false); }
    onSaved();
  };
  const field=(k,label,type='text')=>(
    <div className="grid min-w-0 gap-1.5">
      <label className="text-[11px] font-bold uppercase tracking-wide text-slate-500">{label}</label>
      <input type={type} value={form[k]??''} onChange={e=>set(k,e.target.value)} required className="block box-border min-w-0 w-full max-w-full appearance-none [&::-webkit-date-and-time-value]:min-w-0 [&::-webkit-date-and-time-value]:text-left rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm text-slate-800 outline-none transition focus:border-emerald-600 focus:bg-white focus:ring-2 focus:ring-emerald-200"/>
    </div>
  );
  return (
    <form onSubmit={submit} className="min-w-0 h-fit self-start rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 shadow-sm">
      <div className="flex items-center justify-between gap-2.5">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-emerald-900 text-white"><Droplets size={18}/></span>
          <div>
            <h2 className="text-base font-bold text-charcoal">{edit?'Editar programa':'Programar riego'}</h2>
            <p className="text-xs text-slate-500">Elegí pozo y turno, fecha y horario</p>
          </div>
        </div>
        {edit&&<button type="button" onClick={onCancel} className="text-slate-400 hover:text-slate-600"><X size={18}/></button>}
      </div>
      <div className="mt-5 space-y-4">
        <div className="grid gap-1.5">
          <label className="text-[11px] font-bold uppercase tracking-wide text-slate-500">Pozo</label>
          <select value={form.well} onChange={e=>{set('well',e.target.value);set('turno','');}} className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-800 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-1 focus:ring-emerald-500">
            <option value="">Seleccionar pozo…</option>
            {WELLS.map(w=>{const b=w===form.well?busyWell:(programs||[]).find(p=>busyOverlap(p,w));return <option key={w} value={w} disabled={!!b} className="text-slate-800">{b?`${w} · ocupado ${b.start_time}–${endTime(b)}`:w}</option>;})}
          </select>
          {conflict&&<p className="text-xs font-semibold text-red-600">{form.well} ya está asignado a otro programa ({busyWell.start_time}–{endTime(busyWell)}) en esa fecha y horario.</p>}
        </div>
        {turnos.length>0&&(
          <div className="grid gap-1.5">
            <label className="text-[11px] font-bold uppercase tracking-wide text-slate-500">Turno</label>
            <select value={form.turno} onChange={e=>set('turno',e.target.value)} className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-800 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-1 focus:ring-emerald-500">
              <option value="">Seleccionar turno…</option>
              {turnos.map(t=><option key={t.value} value={t.value}>{t.value} — {t.lots.map(({lot,portion})=>lot+(portion?` ${portion}`:'')).join(' · ')}</option>)}
            </select>
          </div>
        )}
        {selectedTurno&&(
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
            <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500">Lotes del turno</p>
            <ul className="mt-2 space-y-1.5">
              {items.map((it,i)=>(
                <li key={i} className="flex items-center justify-between gap-2 text-sm">
                  <span className={it.lotRec?'text-slate-700':'text-slate-400'}>{it.code}{!it.lotRec&&' · sin lote registrado'}</span>
                  <span className="rounded-full border border-slate-200 bg-white px-2 py-0.5 text-[10px] font-bold uppercase text-slate-600">{PORTION_LABELS[it.portion]||it.portion||'Completo'}</span>
                </li>
              ))}
            </ul>
            {hours>0&&(
              <div className="mt-2 space-y-1 rounded-lg border border-emerald-100 bg-emerald-50 p-2.5">
                {items.map(it=>({...it,portions:[PORTION_LABELS[it.portion]||it.portion||'Completo']})).map((g,i)=>{const d=designs.find(x=>x.lot_id===g.lotRec?.id);const mmh=g.lotRec&&d?(d.emitter_flow_lh||0)*(d.emitters_per_plant||0)*densityOf(g.lotRec)/10000:0;const full=mmh*hours;return(
                  <p key={i} className="text-xs text-emerald-900">{mmh?<>Se regará {g.code} ({g.portions.join(' + ')}). Al lote {g.code} se le cargarán {(full*g.factor).toFixed(1)} mm ({Math.round(g.factor*100)}% de {full.toFixed(1)} mm en {hours.toLocaleString('es-AR',{maximumFractionDigits:1})} h de riego).</>:`Lote ${g.code}: sin diseño de riego cargado, no se pueden calcular los mm.`}</p>
                );})}
              </div>
            )}
          </div>
        )}
        <div className="grid gap-1.5">
          <label className="text-[11px] font-bold uppercase tracking-wide text-slate-500">Fecha de riego</label>
          {mobile?<input type="date" aria-label="Fecha de riego" value={form.date?isoDate(form.date):''} onChange={e=>set('date',toDate(e.target.value))} required className="rounded-lg border bg-white p-3 w-full"/>:(
          <Calendar mode="single" selected={form.date} onSelect={d=>setForm(f=>({...f,date:d,end_date:d?isoDate(d):''}))} locale={es} className="justify-self-start rounded-lg border border-slate-200 p-2 text-xs"/>
          )}
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">{field('start_time','Hora inicio','time')}{field('end_time','Hora fin','time')}</div>
        {field('end_date','Fecha fin (para riegos de varios días)','date')}
        {form.well&&!turnos.length&&<p role="alert" className="text-sm text-amber-800">Este pozo no tiene turnos asignados. Configurá las válvulas en Monitoreo antes de programar.</p>}
        <div className="grid gap-1.5">
          <label className="text-[11px] font-bold uppercase tracking-wide text-slate-500">Estado</label>
          <select value={form.status} onChange={e=>set('status',e.target.value)} className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-800 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-1 focus:ring-emerald-500">
            {STATUSES.map(s=><option key={s}>{s}</option>)}
          </select>
        </div>
        <div className="grid gap-1.5">
          <label className="text-[11px] font-bold uppercase tracking-wide text-slate-500">Notas</label>
          <textarea value={form.notes} onChange={e=>set('notes',e.target.value)} rows="2" placeholder="Observaciones del programa…" className="resize-none rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-800 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-1 focus:ring-emerald-500"/>
        </div>
      </div>
      {error&&<p role="alert" className="mt-4 text-sm text-red-700">{error}</p>}
      {form.end_time&&!hours&&<p role="alert" className="mt-4 text-sm text-red-700">La fecha y hora de fin deben ser posteriores al inicio.</p>}
      <button disabled={busy||conflict||!hours||!form.date||!form.well||!selectedTurno||!items.length||items.some(i=>!i.lotRec)} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-900 py-2.5 font-bold text-white transition hover:bg-emerald-800 disabled:opacity-60">{busy?'Guardando…':edit?<><Pencil size={16}/>Guardar cambios</>:<><Plus size={16}/>Crear programa</>}</button>
    </form>
  );
}
