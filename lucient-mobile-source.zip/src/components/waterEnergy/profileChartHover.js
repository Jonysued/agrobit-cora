const DAY = 86400000;
const dayTs = day => new Date(`${day}T12:00:00`).getTime();

// All lines must use the chart's shared rows. A shorter Line.data array makes
// Recharts mix tooltip indexes and dates across the historical/forecast series.
export function addProbeOverlay(points, history, probeKey, enabled) {
  const byTimestamp = new Map();
  const keys = [];
  let previous = null;
  let segmentKey;
  if (enabled) {
    for (const reading of [...history].sort((a, b) => a.day.localeCompare(b.day))) {
      if (!Number.isFinite(reading.mm)) continue;
      const t = dayTs(reading.day);
      if (previous == null || t - previous !== DAY) {
        segmentKey = `probe-segment-${keys.length}`;
        keys.push(segmentKey);
      }
      byTimestamp.set(t, { value: reading.mm, segmentKey });
      previous = t;
    }
  }
  return {
    keys,
    data: points.map(point => {
      const reading = byTimestamp.get(point.t);
      return { ...point, [probeKey]: reading?.value ?? null, ...(reading ? { [reading.segmentKey]: reading.value } : {}) };
    }),
  };
}

export function hoverPoint(points, label) {
  if (label == null || label === '') return null;
  return points.find(point => point.t === Number(label)) || null;
}
