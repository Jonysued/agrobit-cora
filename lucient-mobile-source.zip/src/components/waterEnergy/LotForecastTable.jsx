import React from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import { mobileNumber } from '@/components/mobile/MobileUI';

// Tabla de forecast por lote — SUMA DE PERFIL (mm almacenados) de
// cada lote (curva propia: riegos ejecutados/programados, clima y
// cultivo), proyección a +3/+7 días, próximo riego y lámina recomendada.
const DOT = { RECARGAR: 'bg-red-500', LLENO: 'bg-emerald-500', 'ÓPTIMO': 'bg-emerald-500' };
// Variación del agua del perfil en las últimas 24 h (mm movidos).
function DailyChange({ mm }) {
  if (mm == null) return <span className="text-slate-300">—</span>;
  if (mm === 0) return <span className="text-xs font-semibold text-slate-500">Sin variación</span>;
  const up = mm > 0;
  return (
    <span className={`text-xs font-bold ${up ? 'text-emerald-700' : 'text-amber-700'}`}>
      {up ? `▲ +${mm} mm` : `▼ ${mm} mm`}
    </span>
  );
}
const fmtDate = s => (s ? new Date(`${s}T00:00:00`).toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit' }) : '—');
const stateText = r => {
  if (!r.profile) return 'Sin perfil de suelo';
  if (!r.state) return 'Sin estado inicial';
  if (r.state.configuration_status === 'incomplete') return 'Config. incompleta';
  return `${r.state.total_profile_water_mm} mm · ${r.state.available_water_percent}% útil`;
};

export default function LotForecastTable({ rows, onOpen }) {
  const mobile = useIsMobile();
  if (!rows.length) {
    return (
      <section className="rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-400">
        No hay lotes cargados para esta finca.
      </section>
    );
  }
  // Misma escala que la columna actual: suma de perfil (agua útil
  // proyectada + agua del punto de marchitez, constante del perfil).
  const cellMm = (r, i) => {
    const p = r.scenarioWithoutIrrigation?.[i];
    if (!p) return '—';
    const wilting = r.state?.wilting_storage_mm ?? 0;
    return `${Math.round((wilting + p.available_water_mm) * 10) / 10} mm`;
  };
  if (mobile) return <section className="mobile-card">{rows.map(r => <button key={r.lot.id} onClick={() => onOpen(r.lot.id)} className="block w-full border-b border-slate-100 py-4 text-left last:border-0"><div className="mobile-pair"><b>{r.lot.name}</b><span className={`mobile-badge ${r.state?.status === 'RECARGAR' ? 'warn' : ''}`}>{r.forecast_status !== 'ok' ? 'Revisar' : r.state?.status === 'RECARGAR' ? 'Bajo umbral' : 'Estable'}</span></div><p className="mobile-muted">{r.forecast_status === 'ok' ? `${mobileNumber(r.state.total_profile_water_mm)} mm estimados` : stateText(r)}</p>{r.forecast_status === 'ok' && <div className={`mobile-progress ${r.state?.status === 'RECARGAR' ? 'warn' : ''}`}><span style={{ width: `${Math.max(0, Math.min(100, r.state.available_water_percent || 0))}%` }} /></div>}</button>)}</section>;
  return (
    <section className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
      <table className="w-full min-w-[860px] text-sm">
        <thead>
          <tr className="border-b border-slate-200 bg-slate-50 text-left text-[11px] uppercase tracking-wide text-slate-500">
            {['Lote', 'Suma de perfil', 'Últimas 24 h', '+3 días', '+7 días', 'Próximo riego', 'MM recomendados', 'Energía estimada'].map(h => <th key={h} className="px-4 py-3">{h}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.lot.id} onClick={() => onOpen(r.lot.id)} className="cursor-pointer border-b border-slate-100 transition hover:bg-emerald-50/60">
              <td className="px-4 py-3"><b className="text-charcoal">{r.lot.name}</b><p className="text-xs text-slate-400">{r.lot.farm} · {r.lot.area_ha} ha</p></td>
              <td className="px-4 py-3">
                {r.forecast_status !== 'ok' ? (
                  <span className="text-xs font-semibold text-amber-600">{stateText(r)}</span>
                ) : (
                  <><span className={`mr-1.5 inline-block h-2.5 w-2.5 rounded-full align-middle ${DOT[r.state.status] || 'bg-slate-300'}`} />{r.state.total_profile_water_mm} mm <span className="text-xs text-slate-400">· {r.state.available_water_percent}% útil</span></>
                )}
              </td>
              <td className="px-4 py-3"><DailyChange mm={r.forecast_status === 'ok' ? r.state?.daily_change_mm : null} /></td>
              <td className="px-4 py-3">{cellMm(r, 2)}</td>
              <td className="px-4 py-3">{cellMm(r, 6)}</td>
              <td className="px-4 py-3">{r.recommendation ? fmtDate(r.recommendation.recommended_start_date) : (r.kc_missing ? <span className="text-xs font-semibold text-amber-600">Falta Kc</span> : '—')}</td>
              <td className="px-4 py-3 font-semibold text-slate-700">{r.recommendation ? `${r.recommendation.recommended_irrigation_mm} mm` : '—'}</td>
              <td className="px-4 py-3 text-slate-600">{r.energy ? `${r.energy.kwh.toLocaleString('es-AR')} kWh` : r.recommendation ? 'Sin bomba asociada' : '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
