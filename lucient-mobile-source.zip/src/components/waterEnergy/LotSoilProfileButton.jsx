import React, { lazy, Suspense, useEffect, useState } from 'react';
import { Pencil } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { waterForecastService } from '@/services/waterEnergy';
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
const ProfileSection = lazy(() => import('./config/ProfileSection'));

function LotProfileEditor({ lot, onSaved, onClose, onBusyChange }) {
  const [profiles, setProfiles] = useState(null);
  const [error, setError] = useState(null);
  useEffect(() => {
    let cancelled = false;
    waterForecastService.getProfiles().then(rows => {
      if (!cancelled) setProfiles(rows.filter(p => p.lot_id === lot.id));
    }).catch(() => { if (!cancelled) setError('No se pudo cargar el perfil. Cerrá y volvé a intentar.'); });
    return () => { cancelled = true; };
  }, [lot.id]);
  if (error) return <p role="alert" className="text-sm text-red-700">{error}</p>;
  if (!profiles) return <p role="status">Cargando perfil…</p>;
  return <Suspense fallback={<p role="status">Cargando editor…</p>}><ProfileSection lots={[lot]} profiles={profiles} initialProfile={profiles[0] || null} editorOnly onClose={onClose} onBusyChange={onBusyChange}
    onChange={async () => { await onSaved?.(); onClose(); }} /></Suspense>;
}

export default function LotSoilProfileButton({ lot, onSaved }) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  if (user?.role !== 'admin') return null;
  return <Dialog open={open} onOpenChange={value => { if (!busy) setOpen(value); }}>
    <DialogTrigger asChild><button type="button" className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl border border-emerald-200 bg-white px-4 py-2 text-sm font-bold text-emerald-800 hover:bg-emerald-50"><Pencil size={16} />Editar perfil de suelo</button></DialogTrigger>
    <DialogContent className="max-w-5xl p-4 sm:p-6" onInteractOutside={e => e.preventDefault()}>
      <DialogTitle className="pr-7">Perfil de suelo · {lot.name}</DialogTitle>
      <DialogDescription>Parámetros de humedad, profundidad radicular, Kc, fenología y todas las capas del perfil de este lote.</DialogDescription>
      <LotProfileEditor lot={lot} onSaved={onSaved} onClose={() => setOpen(false)} onBusyChange={setBusy} />
    </DialogContent>
  </Dialog>;
}
