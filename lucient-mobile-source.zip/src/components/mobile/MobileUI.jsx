import React, { createContext, useContext, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutGrid, Droplets, Zap, Menu, MapPin, ChevronRight, Settings, Sprout, Target, Files, Users, User, Radio, LogOut } from 'lucide-react';
import { useFarm } from '@/lib/FarmContext';
import { useAuth } from '@/lib/AuthContext';
import { backend } from '@/api/backendClient';
import OfflineStatus from '@/components/OfflineStatus';
import '@/mobile.css';
const Context = createContext({ farm: '', setFarm: () => {} });
export const useMobileFarm = () => useContext(Context);
export const mobileNumber = v => v == null || !Number.isFinite(Number(v)) ? '—' : Number(v).toLocaleString('es-AR', { maximumFractionDigits: 1 });
export function MobileDisclosure({title,children,initial=false}){const[open,setOpen]=useState(initial);return <details className="mobile-detail-toggle" open={open} onToggle={e=>setOpen(e.currentTarget.open)}><summary>{title}</summary>{open&&children}</details>;}
export function MobilePage({ title, subtitle, back, children }) { return <div className="mobile-page">{back && <Link className="mobile-back" to={back.to}>‹ {back.label}</Link>}{title && <h1>{title}</h1>}{subtitle && <p className="mobile-subtitle">{subtitle}</p>}{children}</div>; }
export function MobileRow({ to, icon: Icon = ChevronRight, title, detail, value }) { return <Link to={to} className="mobile-row"><span className="mobile-row-icon"><Icon size={18} /></span><span className="mobile-row-copy"><b>{title}</b>{detail && <small>{detail}</small>}</span>{value && <span className="mobile-row-value">{value}</span>}<ChevronRight size={15} className="mobile-chevron" /></Link>; }
export function MobileAction({ to, children, secondary = false, ...props }) { const className = `mobile-action${secondary ? ' mobile-secondary' : ''}`; return to ? <Link to={to} className={className}>{children}</Link> : <button type="button" className={className} {...props}>{children}</button>; }
export function MobileLayout({ children }) {
  const { user } = useAuth(), data = useFarm(), location = useLocation();
  const [farm, updateFarm] = useState(() => { try { return localStorage.getItem('lucient:mobile-farm') ?? ''; } catch { return ''; } });
  const regador = user?.role === 'regador', names = [...new Set(data.Lot.map(l => l.farm).filter(Boolean))].sort(), selected = names.includes(farm) ? farm : '';
  const setFarm = value => { updateFarm(value); try { localStorage.setItem('lucient:mobile-farm', value); } catch { /* selección disponible */ } };
  const initials = (user?.full_name || user?.email || 'Cuenta').split(/\s+/).slice(0, 2).map(s => s[0]).join('').toUpperCase();
  const water = location.pathname === '/riego' || location.pathname.startsWith('/water-energy/lote') || location.pathname.startsWith('/water-energy/sensores');
  const group = water ? 'water' : location.pathname.startsWith('/water-energy') ? 'energy' : ['/dashboard', '/mapa', '/clima'].includes(location.pathname) ? 'home' : 'more';
  return <Context.Provider value={{ farm: selected, setFarm }}><div className={`lucient-mobile${regador ? ' mobile-regador' : ''}`}><header className="mobile-header"><Link to={regador ? '/riego' : '/dashboard'} aria-label="Lucient · Inicio"><img src="/brand/lucient-logo-white.svg" alt="Lucient" /></Link><div className="mobile-header-right">{!regador && <label className="mobile-farm"><MapPin size={13} /><select aria-label="Finca de la vista móvil" value={selected} onChange={e => setFarm(e.target.value)}><option value="">Todas</option>{names.map(n => <option key={n}>{n}</option>)}</select></label>}<Link className="mobile-avatar" to={regador ? '/riego?cuenta=1' : '/mas?cuenta=1'} aria-label="Mi cuenta">{initials}</Link></div></header><main className="mobile-content"><OfflineStatus />{children}</main>{!regador && <nav className="mobile-bottom" aria-label="Secciones de Lucient">{[['home','/dashboard','Inicio',LayoutGrid],['water','/riego','Riego',Droplets],['energy','/water-energy/energia','Energía',Zap],['more','/mas','Más',Menu]].map(([key,to,label,Icon]) => <Link key={key} to={to} className={group === key ? 'selected' : ''} aria-current={group === key ? 'page' : undefined}><Icon size={20} /><span>{label}</span></Link>)}</nav>}</div></Context.Provider>;
}
export function MobileMore({ params }) {
  const { user } = useAuth();
  if (params.get('cuenta')) return <MobilePage title="Mi cuenta" back={{ to: '/mas', label: 'Más' }}><div className="mobile-card"><b>{user?.full_name || user?.email}</b><p className="mobile-muted">{user?.role === 'admin' ? 'Administrador' : 'Usuario'}</p></div><MobileAction secondary onClick={() => backend.auth.logout()}><LogOut size={16} />Cerrar sesión</MobileAction></MobilePage>;
  return <MobilePage title="Más" subtitle="Tu información y herramientas."><div className="mobile-card mobile-menu"><MobileRow to="/lotes" icon={Sprout} title="Lotes" detail="Ficha, cultivo e historial" /><MobileRow to="/mas?objetivos=1" icon={Target} title="Objetivos y producción" detail="Seguimiento por campaña" /><MobileRow to="/documentos" icon={Files} title="Documentos" detail="Planos y archivos de la finca" /></div><h2>Cuenta</h2><div className="mobile-card mobile-menu"><MobileRow to="/configuracion" icon={Settings} title="Configuración" detail="Usuarios y parámetros" /><MobileRow to="/mas?cuenta=1" icon={User} title="Mi cuenta" detail="Perfil y sesión" /></div></MobilePage>;
}
export function MobileSettingsMenu() {
  const { user } = useAuth();
  return <MobilePage title="Configuración" back={{ to: '/mas', label: 'Más' }}><div className="mobile-card mobile-menu">{user?.role === 'admin' && <MobileRow to="/configuracion?tab=usuarios" icon={Users} title="Usuarios y perfiles" detail="Administrador, usuario y regador" />}<MobileRow to="/lotes" icon={Sprout} title="Fincas y lotes" detail="Catálogos y datos agronómicos" /><MobileRow to="/configuracion?tab=water-energy" icon={Droplets} title="Agua y energía" detail="Suelos, sondas, pozos y tarifas" /><MobileRow to="/riego?tab=sensores" icon={Radio} title="Sensores e integraciones" detail="Estado de las conexiones" /><MobileRow to="/configuracion?tab=produccion" icon={Target} title="Históricos de producción" /><MobileRow to="/configuracion?tab=administracion" icon={Settings} title="Administración general" detail="Importaciones, campañas y rangos" /></div></MobilePage>;
}
