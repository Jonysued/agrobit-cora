import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { CalendarDays, Radio, Map, Target, Activity, Sun } from 'lucide-react';
import { deviceStatus } from '@/services/irrigation/monitoringUtils';
import { weatherService } from '@/services/waterEnergy/weatherService';
import { MobilePage, MobileRow, MobileAction, mobileNumber } from './MobileUI';
export default function MobileDashboard({ lots, rows, devices, turns, upcoming, scheduled, climateFarm, monitorStatus, balanceStatus }) {
  const climate = useQuery({ queryKey: ['mobile-weather', climateFarm?.id], queryFn: () => weatherService.getCombinedWeather(climateFarm), enabled: !!climateFarm, staleTime: 120000 });
  const wells = devices.filter(d => d.kind === 'well' && d.current_active);
  const valves = devices.filter(d => d.kind === 'valve' && deviceStatus(d, devices).effective);
  const wetIds = new Set(valves.flatMap(v => v.lot_ids || []));
  const under = rows.filter(r => r.state && r.state.current_available_water_mm <= r.state.recharge_threshold_mm);
  const current = climate.data?.current;
  const next = upcoming ? `${new Date(upcoming.date + 'T12:00:00').toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })} · ${upcoming.start_time?.slice(0,5)}` : 'Sin turno agendado';
  return <MobilePage title="Resumen del campo" subtitle={new Date().toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'America/Argentina/Buenos_Aires' })}>
    <div className="mobile-card mobile-hero"><div className="mobile-pair"><span className="mobile-kicker">Riego en curso</span><span className="mobile-badge neutral">{monitorStatus || `${wells.length} pozos`}</span></div><div className="mobile-value">{monitorStatus || wetIds.size} <small>lotes regando</small></div><p className="mobile-muted">{monitorStatus || `${valves.length} válvulas con riego efectivo registrado.`}</p><MobileAction to="/riego?tab=monitoreo"><Radio size={16} />Ver monitoreo</MobileAction></div>
    <div className="mobile-split"><div className="mobile-card"><p className="mobile-kicker">Para revisar</p><div className="mobile-value">{balanceStatus || under.length} <small>lotes</small></div><MobileAction secondary to="/riego?tab=balance">Ver balance</MobileAction></div><div className="mobile-card"><p className="mobile-kicker">Energía programada</p><div className="mobile-value">{mobileNumber(scheduled?.totalKwh)} <small>kWh</small></div><p className="mobile-muted">Próximos 7 días</p></div></div>
    <h2 className="mt-6">Hoy</h2><div className="mobile-card mobile-menu"><MobileRow to="/clima" icon={Sun} title={current?.temperature_c == null ? 'Clima y pronóstico' : `${mobileNumber(current.temperature_c)}° · ${climate.data.station?.name || 'Estación'}`} detail={current?.rainfall_mm == null ? 'Ver condiciones meteorológicas' : `Lluvia observada: ${mobileNumber(current.rainfall_mm)} mm`} /><MobileRow to="/riego?tab=cronograma" icon={CalendarDays} title="Próximo turno" detail={upcoming?.well || 'Cronograma de riegos'} value={next} /><MobileRow to="/mapa" icon={Map} title="Mapa de la finca" detail={`${lots.length} lotes · abrir vista completa`} /></div>
    <h2>Seguimiento</h2><div className="mobile-card mobile-menu"><MobileRow to="/mas?objetivos=1" icon={Target} title="Objetivos de campaña" detail="Seguimiento de producción" /><MobileRow to="/riego?tab=sensores" icon={Activity} title="Sensores" detail="Últimas lecturas y estado de conexión" /><MobileRow to="/riego?tab=recomendaciones" icon={CalendarDays} title="Recomendaciones" detail={turns ? `${turns.filter(g => g.recommendation).length} turnos sugeridos` : 'Calculando…'} /></div>
  </MobilePage>;
}
