import React, { lazy, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Sprout } from 'lucide-react';
import { useFarm } from '@/lib/FarmContext';
import LoadingState from '@/components/LoadingState';
import { MobilePage, MobileRow, MobileAction, MobileDisclosure, useMobileFarm, mobileNumber } from './MobileUI';
import { ageOf, densityOf } from '@/lib/farmCalculations';
const SummaryTab = lazy(() => import('@/components/lot/SummaryTab'));
const ProductionTab = lazy(() => import('@/components/lot/ProductionTab'));
const HealthTab = lazy(() => import('@/components/lot/HealthTab'));
const IrrigationTab = lazy(() => import('@/components/lot/IrrigationTab'));
const ObservationsTab = lazy(() => import('@/components/lot/ObservationsTab'));
const PruningTab = lazy(() => import('@/components/lot/PruningTab'));
const ObjectivesTab = lazy(() => import('@/components/lot/ObjectivesTab'));
const LotEditModal = lazy(() => import('@/components/lot/LotEditModal'));
export function MobileLots() {
  const d=useFarm(), {farm}=useMobileFarm(), [search,setSearch]=useState('');
  if(d.loading)return <LoadingState/>;
  const lots=d.Lot.filter(l=>(!farm||l.farm===farm)&&`${l.name} ${l.crop} ${l.variety}`.toLowerCase().includes(search.toLowerCase()));
  return <MobilePage title="Lotes" subtitle="Ficha agronómica e historial." back={{to:'/mas',label:'Más'}}><label className="block text-xs mt-4 text-slate-500">Buscar lote<input aria-label="Buscar lote" value={search} onChange={e=>setSearch(e.target.value)} className="mt-2 block w-full rounded-lg border bg-white p-3" placeholder="Nombre del lote"/></label><div className="mobile-card mobile-menu">{lots.map(l=><MobileRow key={l.id} to={`/lotes/${l.id}`} icon={Sprout} title={l.name} detail={`${l.crop||'Sin cultivo'} · ${l.farm||''}`} value={`${mobileNumber(l.area_ha)} ha`}/>)}{!lots.length&&<p className="mobile-muted py-4">No hay lotes que coincidan con la búsqueda.</p>}</div></MobilePage>;
}
export function MobileLotDetail(){
  const {id}=useParams(),d=useFarm(),[edit,setEdit]=useState(false);
  if(d.loading)return <LoadingState/>;
  const lot=d.Lot.find(l=>l.id===id);
  if(!lot)return <MobilePage title="Lote no encontrado" back={{to:'/lotes',label:'Lotes'}}/>;
  return <MobilePage title={lot.name} subtitle={`${lot.farm||''} · ${lot.sector||''}`} back={{to:'/lotes',label:'Lotes'}}><div className="mobile-card"><p className="mobile-kicker">Cultivo</p><h2>{lot.crop} · {lot.variety}</h2><div className="mobile-state-row"><span>Superficie</span><b>{mobileNumber(lot.area_ha)} ha</b></div><div className="mobile-state-row"><span>Edad</span><b>{ageOf(lot)} años</b></div><div className="mobile-state-row"><span>Densidad</span><b>{mobileNumber(densityOf(lot))} plantas/ha</b></div></div><MobileAction to={`/water-energy/lote/${lot.id}`}>Ver balance hídrico</MobileAction><MobileAction secondary to="/mapa">Ver en mapa</MobileAction><MobileDisclosure title="Resumen del lote"><SummaryTab lot={lot} data={d}/></MobileDisclosure><MobileDisclosure title="Plantación y diseño de riego"><IrrigationTab lot={lot} data={d}/></MobileDisclosure><MobileDisclosure title="Historial de campañas"><ProductionTab lot={lot} data={d}/></MobileDisclosure><MobileDisclosure title="Objetivos de campaña"><ObjectivesTab lot={lot} data={d}/></MobileDisclosure><MobileDisclosure title="Sanidad y podas"><HealthTab lot={lot} data={d}/><PruningTab lot={lot} data={d}/></MobileDisclosure><MobileDisclosure title="Observaciones"><ObservationsTab lot={lot} data={d}/></MobileDisclosure>{<MobileAction secondary onClick={()=>setEdit(true)}>Editar lote</MobileAction>}{edit&&<LotEditModal lot={lot} onSaved={d.refetch} onClose={()=>setEdit(false)}/>}</MobilePage>;
}
