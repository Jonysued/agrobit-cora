import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Radio, CalendarDays, Droplets, Activity } from 'lucide-react';
import { waterForecastService } from '@/services/waterEnergy';
import { monitoringService } from '@/services/irrigation/monitoringService';
import InitialMoistureNotice from '@/components/waterEnergy/InitialMoistureNotice';
import { MobileRow, MobileAction, useMobileFarm } from './MobileUI';
export default function MobileWaterSummary() {
  const { farm } = useMobileFarm();
  const overview = useQuery({ queryKey: ['mobile-water-overview'], queryFn: () => waterForecastService.getFarmOverview(), staleTime: 60000 });
  const devices = useQuery({ queryKey: ['irrigation-monitor', 'devices'], queryFn: monitoringService.devices, staleTime:15000, refetchInterval: 15000 });
  const turns = (overview.data?.turns || []).filter(g => !farm || g.well.farm === farm), recommendations = turns.filter(g => g.recommendation);
  const active = (devices.data || []).filter(v => v.kind === 'well' && v.current_active && (!farm || v.farm === farm));
  return <><p className="mobile-subtitle">Decisiones de riego{farm ? ` · ${farm}` : ''}</p><div className="mobile-card mobile-hero"><p className="mobile-kicker">Qué necesita atención</p><div className="mobile-value">{overview.isPending ? 'Calculando…' : recommendations.length} <small>turnos sugeridos</small></div><p className="mobile-muted">La prioridad de cada turno la define su lote más seco.</p><MobileAction to="/riego?tab=recomendaciones">Ver recomendaciones</MobileAction></div><InitialMoistureNotice />{overview.isError && <p className="mobile-note" role="alert">No se pudo calcular el resumen. <button onClick={() => overview.refetch()}>Reintentar</button></p>}<div className="mobile-card mobile-menu"><MobileRow to="/riego?tab=monitoreo" icon={Radio} title="Monitoreo en vivo" detail={devices.isError ? 'No se pudo actualizar' : devices.isPending ? 'Cargando equipos…' : `${active.length} pozos encendidos`} /><MobileRow to="/riego?tab=cronograma" icon={CalendarDays} title="Cronograma" detail="Turnos agendados y próximos días" /><MobileRow to="/riego?tab=balance" icon={Droplets} title="Balance hídrico" detail="Humedad y curvas por lote" /><MobileRow to="/riego?tab=sensores" icon={Activity} title="Sensores" detail="Últimas lecturas y conexión" /></div></>;
}
