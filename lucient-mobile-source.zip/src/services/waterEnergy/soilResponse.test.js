import test from 'node:test';
import assert from 'node:assert/strict';
import { probeProfileLoss, forecastDrydownFactor, afterRiseFactor, drydownFactor } from './soilResponse.js';
import { runUsefulWaterScenario } from './engine/waterBalanceEngine.js';
const model = { calibration_diagnostics: { last_probe_day:'2026-10-08',reference_taw_mm:100,
  transfer_dynamics:{version:1,last_clean_day:'2026-10-08',recent_loss_mm_day:2,loss_per_eto:0.5,
    daily:[{day:'2026-10-07',loss_mm:2},{day:'2026-10-08',loss_mm:0}]}}};
test('histórico sigue la pérdida medida, escala capacidad y respeta pérdida cero',()=>{
  assert.equal(probeProfileLoss(model,{date:'2026-10-07',lotTaw:100}),2);
  assert.equal(probeProfileLoss(model,{date:'2026-10-07',lotTaw:200}),4);
  assert.equal(probeProfileLoss(model,{date:'2026-10-08'}),0);
  assert.equal(probeProfileLoss(model,{date:'2026-10-01'}),null);
});
test('pronóstico sigue secado limpio ajustado por clima, sin ciclo del riego donante',()=>{
  assert.equal(probeProfileLoss(model,{date:'2026-10-09',forecastFactor:1,eto:6,lotTaw:200}),6);
  assert.equal(probeProfileLoss(model,{date:'2026-11-01',forecastFactor:1,eto:6}),null);
  assert.equal(probeProfileLoss(null,{eto:6}),null);
  assert.equal(drydownFactor(model),1);
  assert.equal(afterRiseFactor(model),1);
  assert.equal(forecastDrydownFactor(model,0,0),1);
});
test('el nivel inicial y la recarga pertenecen al lote, con o sin riego programado',()=>{
  const config={total_available_water_capacity_mm:100,recharge_threshold_mm:20,target_water_mm:80};
  const days=[{date:'2026-10-09',profile_loss_mm:2,irrigation_mm:10},{date:'2026-10-10',profile_loss_mm:2}];
  const dry=runUsefulWaterScenario(50,config,days.map(d=>({...d,irrigation_mm:0})));
  const irrigated=runUsefulWaterScenario(50,config,days);
  assert.equal(dry[1].available_water_mm,46);
  assert.equal(irrigated[1].available_water_mm,56);
});

test('una única ventana provisional no conduce el pronóstico ni rompe el histórico observado', () => {
  const model={calibration_diagnostics:{transfer_dynamics:{version:1,revision:2,forecast_usable:false,
    last_clean_day:'2026-10-12',recent_loss_mm_day:null,loss_per_eto:null,
    daily:[{day:'2026-10-10',loss_mm:2}]}}};
  assert.equal(probeProfileLoss(model,{date:'2026-10-14',eto:3,forecastFactor:1}),null);
  assert.equal(probeProfileLoss(model,{date:'2026-10-10',eto:3}),2);
});

const response = { calibration_diagnostics: { last_probe_day: '2026-10-12',
  drydown_cycle: [{day:1,fall_mm:10.3},{day:2,fall_mm:6.3},{day:3,fall_mm:2}],
  transfer_dynamics: { version:1, forecast_usable:true,recent_loss_mm_day:2, loss_per_eto:0.5,
    daily_profile:[{day:'2026-10-09',mm:100},{day:'2026-10-10',mm:120},
      {day:'2026-10-11',mm:109.7},{day:'2026-10-12',mm:103.4}] } } };
const {advanceLotCycle,lotCycleLoss} = await import('./soilResponse.js');
test('lot uses measured early fall after its own recharge, then stable fall',()=>{
  let cycle=advanceLotCycle(null,20);
  assert.equal(lotCycleLoss(response,{date:'2026-10-13',eto:4,cycle}),2);
  cycle=advanceLotCycle(cycle);
  assert.equal(lotCycleLoss(response,{date:'2026-10-13',eto:4,cycle}),10.3);
  cycle=advanceLotCycle(cycle);
  assert.equal(lotCycleLoss(response,{date:'2026-10-14',eto:4,cycle}),6.3);
  cycle=advanceLotCycle(cycle);
  assert.equal(lotCycleLoss(response,{date:'2026-10-15',eto:4,cycle}),2);
});
test('probe recharge dates and current phase cannot reset a dry lot',()=>{
  const donor={calibration_diagnostics:{...response.calibration_diagnostics,current_drydown_phase:1}};
  const cycle=advanceLotCycle(null);
  assert.equal(cycle.phase,null);
  assert.equal(lotCycleLoss(donor,{date:'2026-10-13',eto:4,cycle}),2);
});
test('smaller net lot recharge reduces extra early loss, not the stable baseline',()=>{
  const cycle=advanceLotCycle(advanceLotCycle(null,10));
  assert.equal(lotCycleLoss(response,{date:'2026-10-13',eto:4,cycle}),6.2);
});
test('historical reconstruction never learns from future probe data',()=>{
  const opts={date:'2026-10-12',learningThrough:'2026-10-11',eto:4,
    cycle:{phase:1,rechargeMm:20}};
  const changed=structuredClone(response);
  changed.calibration_diagnostics.transfer_dynamics.daily_profile.at(-1).mm=0;
  changed.calibration_diagnostics.drydown_cycle[0].fall_mm=99;
  assert.equal(lotCycleLoss(response,opts),10.3);
  assert.equal(lotCycleLoss(changed,opts),10.3);
});
test('stale probe response does not drive a current projection',()=>{
  assert.equal(lotCycleLoss(response,{date:'2026-11-01',eto:4,cycle:{phase:1,rechargeMm:20}}),null);
});

test('confirmed terminal windows supply historical depletion without double counting derived days',()=>{
  const windowModel={calibration_diagnostics:{last_probe_day:'2026-10-14',transfer_dynamics:{
    daily_profile:[{day:'2026-10-12',mm:100},{day:'2026-10-13',mm:110}],
    daily:[{day:'2026-10-12',loss_mm:99,source:'estimated_from_window'}],
    clean_windows:[{day:'2026-10-01',loss_mm:1.5,confirmed_at:Date.parse('2026-10-01T12:00:00-03:00')},
      {day:'2026-10-12',loss_mm:4.1,confirmed_at:Date.parse('2026-10-12T18:00:00-03:00')}],
  }}};
  assert.equal(lotCycleLoss(windowModel,{date:'2026-10-13',learningThrough:'2026-10-12',eto:3,meanEto:3}),2.8);
  assert.equal(lotCycleLoss(windowModel,{date:'2026-10-12',learningThrough:'2026-10-11',eto:3,meanEto:3}),null);
  const late=structuredClone(windowModel);
  late.calibration_diagnostics.transfer_dynamics.clean_windows[1].confirmed_at=Date.parse('2026-10-13T00:01:00-03:00');
  assert.equal(lotCycleLoss(late,{date:'2026-10-13',learningThrough:'2026-10-12',eto:3,meanEto:3}),null);
});

test('matching recent completed probe phase replaces the flattened old median',()=>{
  const recent=structuredClone(response);
  recent.calibration_diagnostics.drydown_cycle[0].fall_mm=1.3;
  recent.calibration_diagnostics.transfer_dynamics.daily_profile.push(
    {day:'2026-10-13',mm:123.4},{day:'2026-10-14',mm:116.5});
  recent.calibration_diagnostics.last_probe_day='2026-10-14';
  recent.calibration_diagnostics.transfer_dynamics.last_completed_day='2026-10-14';
  assert.equal(lotCycleLoss(recent,{date:'2026-10-15',eto:4,cycle:{phase:1,rechargeMm:20}}),6.9);
  assert.equal(lotCycleLoss(recent,{date:'2026-10-14',learningThrough:'2026-10-13',eto:4,
    cycle:{phase:1,rechargeMm:20}}),10.3);
  recent.calibration_diagnostics.transfer_dynamics.last_completed_day='2026-10-13';
  assert.equal(lotCycleLoss(recent,{date:'2026-10-15',eto:4,cycle:{phase:1,rechargeMm:20}}),10.3);
});
