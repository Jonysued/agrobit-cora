import { backend } from '@/api/backendClient';
import { monitoringService } from '@/services/irrigation/monitoringService';
import { assignedPrograms, pendingLotSchedule, businessDay } from '@/services/irrigation/planning';
import { densityOf } from '@/lib/farmCalculations';
import { kcService } from './kcService';
import { soilWaterService, computeProfileConfig, fullProfileDepthCm, DEFAULT_FULL_PROFILE_DEPTH_CM } from './soilWaterService';
import { soilBehaviorService } from './soilBehaviorService';
import { selectGaritaStation, aggregateGaritaObservations } from './garitaWeather';
import { advanceLotCycle, lotCycleLoss } from './soilResponse';
import { reconstructProfile } from './engine/profileTimeline';

// ============================================================
// lotWaterStateService — ESTADO HÍDRICO CALCULADO DE CADA LOTE.
//
// La curva de cada lote es una CURVA CALCULADA, no una lectura de
// sonda. Evoluciona con los eventos PROPIOS del lote:
//
//   estado hídrico anterior
//   + riegos ejecutados (Monitoreo → duración efectiva × intensidad del diseño)
//   + riegos programados (IrrigationProgram, futuro)
//   + lluvia observada / pronosticada
//   − demanda del cultivo (ETc = ET0 × Kc)
//   × comportamiento del suelo de referencia (SoilBehaviorModel:
//     eficiencia de recarga, agotamiento)
//
// SOLO LECTURA: una consulta de UI nunca escribe LotWaterState. El
// ORIGEN de la curva es una inicialización EXPLÍCITA del usuario
// (valor manual o estado inicial guardado); desde ese origen la curva
// se RECONSTRUYE completa en cada consulta. La sonda de referencia
// NUNCA inicializa ni iguala el estado del lote — solo alimenta el
// modelo de comportamiento del suelo.
//
// MODEL_VERSION: versión del modelo de balance (se registra en cada
// estado persistido para trazabilidad).
// ============================================================
const MODEL_VERSION = 'v2';
const EFFECTIVE_RAIN_FACTOR = 0.7;
// Fondo del perfil de cálculo (cm): el estado hídrico CALCULADO de un
// lote se integra SIEMPRE sobre el perfil completo 0–120 cm. La sonda
// de referencia define el fondo con sus profundidades (10–115 → 120);
// sin sonda de referencia se usa el estándar DEFAULT_FULL_PROFILE_DEPTH_CM
// (importado de soilWaterService).
const round1 = n => Math.round(n * 10) / 10;
const pad = n => String(n).padStart(2, '0');
const isoDay = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const todayStr = () => businessDay();
const dayAfter = (iso, n) => { const d = new Date(`${iso}T12:00:00`); d.setDate(d.getDate() + n); return isoDay(d); };
// Límite de reconstrucción hacia atrás (días) desde el ancla
const MAX_HISTORY_DAYS = 180;


// ---- Fondo del perfil completo (0–N cm) de un lote ----
// Definido por la sonda de referencia de su modelo de suelo (ej.
// sonda 10–115 cm → 0–120 cm). Sin sonda de referencia → null: la
// integración se hace sobre la zona radicular configurada.
async function referenceFullDepthCm(profile, models) {
  const model = soilBehaviorService.getModelForProfile(profile, models);
  const refProbeId = model?.reference_probe_id || profile.probe_id;
  if (!refProbeId) return DEFAULT_FULL_PROFILE_DEPTH_CM;
  const channels = await backend.entities.SoilProbeChannel.filter({ probe_id: refProbeId });
  return fullProfileDepthCm(channels.map(c => c.depth_cm)) ?? DEFAULT_FULL_PROFILE_DEPTH_CM;
}

// ---- Contexto compartido (una sola pasada para todos los lotes) ----
async function loadContext(lots) {
  let [profiles, models, states, programs, allLayers, allChannels, designs, stations, allLots] = await Promise.all([
    backend.entities.SoilProfile.list(),
    soilBehaviorService.getModels(),
    backend.entities.LotWaterState.list('-timestamp', 2000),
    backend.entities.IrrigationProgram.list(),
    backend.entities.SoilLayer.list(),
    backend.entities.SoilProbeChannel.list(),
    backend.entities.IrrigationDesign.list(),
    backend.entities.WeatherStation.list(),
    backend.entities.Lot.list(),
  ]);
  // Configuración estática de cada perfil (SIN sonda) — capas cargadas
  // UNA sola vez para todos los perfiles: sin consultas por perfil.
  const layersByProfile = new Map();
  for (const layer of allLayers) {
    if (!layersByProfile.has(layer.soil_profile_id)) layersByProfile.set(layer.soil_profile_id, []);
    layersByProfile.get(layer.soil_profile_id).push(layer);
  }
  // Configuración de cada perfil integrada sobre el PERFIL COMPLETO
  // definido por su sonda de referencia (ej. 0–120 cm)
  const configs = new Map();
  for (const p of profiles) {
    const model = soilBehaviorService.getModelForProfile(p, models);
    const refProbeId = model?.reference_probe_id || p.probe_id;
    const depths = refProbeId ? allChannels.filter(c => c.probe_id === refProbeId).map(c => c.depth_cm) : [];
    configs.set(p.id, computeProfileConfig(p, layersByProfile.get(p.id) || [], fullProfileDepthCm(depths) ?? DEFAULT_FULL_PROFILE_DEPTH_CM));
  }
  // Escalar solo cuando conocemos el suelo de la ubicación física de la
  // sonda o todos sus perfiles vinculados tienen la misma capacidad.
  for (const model of models) {
    const linked = profiles.filter(p => p.probe_id === model.reference_probe_id || p.soil_behavior_model_id === model.id);
    const donor = linked.find(p => p.lot_id === model.calibration_diagnostics?.reference_lot_id);
    const capacities = linked.map(p => configs.get(p.id)?.total_available_water_capacity_mm).filter(v => v > 0);
    const reference = donor ? configs.get(donor.id)?.total_available_water_capacity_mm
      : capacities.length && capacities.length === linked.length && capacities.every(v => v === capacities[0]) ? capacities[0] : null;
    model.calibration_diagnostics = { ...model.calibration_diagnostics, reference_taw_mm: reference ?? null };
  }
  // Una sola serie observada de Garita para TODOS los lotes, aunque
  // Garita esté vinculada únicamente a una finca en la configuración.
  const garita = selectGaritaStation(stations);
  const observations = garita
    ? await backend.entities.WeatherObservation.filter({ weather_station_id: garita.id }, '-timestamp', 2000)
    : [];
  const observed = aggregateGaritaObservations(observations);
  const [observedIrrigation, devices] = await Promise.all([monitoringService.observed(lots, designs), monitoringService.devices()]);
  programs = assignedPrograms(programs, devices);
  return { profiles, models, states, configs, garita, observed, programs, designs, allLots, referenceKcCache: new Map(), observedIrrigation };
}

function referenceKc(ctx, model, date) {
  const probeId = model?.reference_probe_id;
  if (!probeId) return null;
  const key = `${probeId}|${date}`;
  if (ctx.referenceKcCache.has(key)) return ctx.referenceKcCache.get(key);
  const linked = ctx.profiles.filter(p => p.probe_id === probeId
    || (p.soil_behavior_model_id && ctx.models.some(m => m.id === p.soil_behavior_model_id && m.reference_probe_id === probeId)));
  const kc = linked.map(p => {
    const lot = ctx.allLots.find(l => l.id === p.lot_id);
    return lot ? kcService.kcForLotDate(lot, date, p) : null;
  }).filter(Number.isFinite).sort((a, b) => a - b);
  const mid = Math.floor(kc.length / 2);
  const result = kc.length ? (kc.length % 2 ? kc[mid] : (kc[mid - 1] + kc[mid]) / 2) : null;
  ctx.referenceKcCache.set(key, result);
  return result;
}

// ---- Estado de UN lote: ancla + reconstrucción diaria hasta hoy ----
async function computeLot(lot, ctx, withHistory) {
  const profile = ctx.profiles.find(p => p.lot_id === lot.id);
  if (!profile) return { lot, profile: null, config: null, model: null, forecast_status: 'no_disponible', reason: 'sin_perfil' };
  const config = ctx.configs.get(profile.id);
  const model = soilBehaviorService.getModelForProfile(profile, ctx.models);
  const efficiency = model?.recharge_efficiency != null ? model.recharge_efficiency : 1;
  const etcCorrectionFactor = model?.etc_correction_factor != null ? model.etc_correction_factor : 1;
  const taw = config?.total_available_water_capacity_mm ?? null;
  const wilting = config?.wilting_storage_mm ?? 0;
  const configComplete = config?.configuration_status === 'complete';

  // ---- Origen del estado: inicialización EXPLÍCITA del usuario ----
  // Se aceptan únicamente un LotWaterState creado explícitamente
  // (manual o estimación guardada por el usuario) o el valor manual
  // del perfil. La sonda JAMÁS inicializa el estado del lote: es solo
  // referencia para aprender el comportamiento del suelo.
  const stateRecs = ctx.states.filter(s => s.lot_id === lot.id);
  let anchor = null;
  const explicit = stateRecs.find(s => s.source === 'manual_adjustment' || s.source === 'initialized');
  if (explicit) {
    // La inicialización más reciente: una nueva inicialización reinicia la curva
    anchor = {
      date: businessDay(Date.parse(explicit.timestamp)),
      useful: Math.max(0, round1((explicit.profile_water_mm ?? 0) - wilting)),
      source: explicit.source,
      from: Date.parse(explicit.timestamp),
    };
  } else if (stateRecs.length) {
    // Registros legados diarios: el más antiguo es el punto de partida
    const first = stateRecs[stateRecs.length - 1];
    anchor = {
      date: businessDay(Date.parse(first.timestamp)),
      useful: Math.max(0, round1((first.profile_water_mm ?? 0) - wilting)),
      source: 'calculated',
      from: Date.parse(first.timestamp),
    };
  } else if (configComplete && profile.manual_initial_water_mm != null) {
    anchor = { date: todayStr(), useful: profile.manual_initial_water_mm, source: 'manual_adjustment' };
  }
  if (!anchor) {
    return {
      lot, profile, config, model, efficiency,
      forecast_status: 'no_disponible',
      reason: configComplete ? 'sin_estado_inicial' : 'config_incompleta',
    };
  }
  if (!ctx.garita || !ctx.observed.lastObservationAt) {
    return {
      lot, profile, config, model,
      forecast_status: 'no_disponible',
      reason: ctx.garita ? 'sin_datos_garita' : 'sin_estacion_garita',
    };
  }
  // Rango físico del origen: nunca por encima de la capacidad útil
  // (el excedente drena) ni por debajo del punto de marchitez. Sin
  // esto, un origen fuera de rango hace que el primer día del
  // forecast recorte la curva y el gráfico no refleje el valor inicial.
  if (taw != null && anchor.useful > taw) anchor = { ...anchor, useful: taw };
  if (anchor.useful < 0) anchor = { ...anchor, useful: 0 };
  // El ancla es AUTORITATIVA. Un riego anterior a su fecha ya está
  // implícito en la medición/valor inicial y jamás se vuelve a sumar.

  // ---- Reconstrucción diaria: ancla → hoy ----
  // eventos propios del lote + clima observado + demanda del cultivo,
  // modulados por el comportamiento del suelo de referencia.
  const end = todayStr();
  let startDay = anchor.date;
  if (startDay < dayAfter(end, -(MAX_HISTORY_DAYS - 1))) startDay = dayAfter(end, -(MAX_HISTORY_DAYS - 1));
  const actualSinceAnchor = await monitoringService.observed([lot], ctx.designs, anchor.from ?? Date.parse(`${anchor.date}T00:00:00-03:00`));
  const executed = new Map([...(actualSinceAnchor.byLot.get(lot.id) || [])].map(([date, event]) => [date, event.mm ?? 0]));
  const obs = ctx.observed;
  const asOf = actualSinceAnchor.asOf;
  const from = Math.max(anchor.from ?? Date.parse(`${anchor.date}T00:00:00-03:00`),
    Date.parse(`${startDay}T00:00:00-03:00`));
  const rainfall = (obs.rainEntries || []).filter(e => e.time > from && e.time <= asOf);
  const rainByDate = new Map();
  for (const event of rainfall) rainByDate.set(event.day, (rainByDate.get(event.day) || 0) + event.mm);
  const irrigationEvents = [...executed].filter(([, mm]) => mm > 0)
    .map(([date, mm]) => ({ date, mm: round1(mm * efficiency) }));
  const rainEvents = [...rainByDate].map(([date, mm]) => ({date, mm: round1(mm), effective_mm: round1(mm * EFFECTIVE_RAIN_FACTOR)}));
  let estimatedEtoDays = 0;
  let missingRainDays = 0;
  let lotCycle = { phase: null, rechargeMm: 0 };
  const dailyLoss = new Map();
  // The observed rain/irrigation enters at its timestamp, once. The daily
  // loss rate drives the same timeline used for both the chart and 24 h.
  for (let day = startDay; day <= end; day = dayAfter(day, 1)) {
    const recharge = (executed.get(day) || 0) * efficiency
      + (rainByDate.get(day) || 0) * EFFECTIVE_RAIN_FACTOR;
    lotCycle = advanceLotCycle(lotCycle, recharge);
    if (!obs.byDay.has(day)) missingRainDays++;
    let eto = obs.byDay.get(day)?.eto ?? obs.meanEto;
    if (obs.byDay.get(day)?.eto == null) estimatedEtoDays++;
    // Today's counter is incomplete. Use an observed daily reference rate
    // and account only for elapsed time; never subtract a whole future day.
    if (day === end && obs.meanEto != null) eto = Math.max(eto ?? 0, obs.meanEto);
    const kc = kcService.kcForLotDate(lot, day, profile);
    const learned = eto != null ? lotCycleLoss(model, { date: day, eto,
      meanEto: obs.meanEto, cycle: lotCycle, learningThrough: dayAfter(day, -1) }) : null;
    dailyLoss.set(day, learned ?? (kc != null && eto != null ? round1(eto * kc * etcCorrectionFactor) : 0));
  }
  const deliveries = (actualSinceAnchor.deliveries || []).filter(d => d.lotId === lot.id)
    .map(d => ({ ...d, mmPerHour: d.mmPerHour * efficiency }));
  const timeline = reconstructProfile({ start: from, end: asOf, initialMm: anchor.useful,
    capacityMm: taw, dailyLoss, deliveries,
    rain: rainfall.map(e => ({ ...e, mm: e.mm * EFFECTIVE_RAIN_FACTOR })) });
  const water = timeline?.currentMm ?? anchor.useful;
  const history = timeline?.history ?? [{ date: startDay, mm: anchor.useful }];
  const previousStepHadRecharge = lotCycle.phase === 0;

  // ---- Sin retro-proyección ----
  // La curva calculada ARRANCA en la fecha de inicialización del
  // estado hídrico: no se dibuja evolución previa (la línea no se ve
  // hacia atrás del punto de partida).

  // ---- Programados del lote (futuro) con eficiencia del modelo ----
  // Un evento por PROGRAMA (guarda program_id para identificarlo en el
  // cronograma; nunca prueba su ejecución). gross_mm = lámina a aplicar del
  // cronograma (mm explícitos del programa o derivados de su diseño
  // de riego y duración); mm = efecto neto sobre el perfil (gross ×
  // eficiencia de recarga aprendida del suelo).
  const design = ctx.designs.find(d => d.lot_id === lot.id);
  const rate = design ? (design.emitter_flow_lh || 0) * (design.emitters_per_plant || 0) * densityOf(lot) / 10000 : 0;
  const scheduledPrograms = pendingLotSchedule(ctx.programs, lot, rate, ctx.observedIrrigation.asOf)
    .map(e => ({ ...e, gross_mm: round1(e.gross_mm), mm: round1(e.gross_mm * efficiency), program_id: e.program_ids[0] }));
  // Agregado por fecha para el gráfico (puede haber varios programas
  // el mismo día).
  const scheduledAgg = new Map();
  for (const e of scheduledPrograms) scheduledAgg.set(e.date, round1((scheduledAgg.get(e.date) || 0) + e.mm));
  const scheduledEvents = [...scheduledAgg.entries()]
    .map(([date, mm]) => ({ date, mm }))
    .sort((a, b) => a.date.localeCompare(b.date));
  const daily_change_mm = timeline?.change24h ?? null;
  return {
    lot, profile, config, model,
    efficiency,
    as_of: asOf,
    etc_correction_factor: etcCorrectionFactor,
    soil_response_factor: 1,
    post_rise_factor: 1,
    reference_kc_by_date: Object.fromEntries(Array.from({ length: 15 }, (_, i) => {
      const day = dayAfter(end, i + 1);
      return [day, referenceKc(ctx, model, day)];
    })),
    garita_mean_eto: obs.meanEto,
    recent_recharge: previousStepHadRecharge,
    lot_response_cycle: lotCycle,
    daily_change_mm,
    currentUsefulMm: water,
    currentStoredMm: round1(wilting + water),
    state_source: anchor.source,
    origin: anchor.source,
    anchored_at: anchor.date,
    data_quality: {
      irrigation_warnings: actualSinceAnchor.warnings.get(lot.id) || [],
      irrigation_source: 'monitoreo',
      anchor_date: anchor.date,
      observed_weather_last_at: obs?.lastObservationAt || null,
      observed_weather_station: ctx.garita?.name || null,
      observed_weather_source: ctx.garita ? 'Garita' : 'sin_estacion_garita',
      estimated_eto_days: estimatedEtoDays,
      missing_rain_days: missingRainDays,
      daily_change_source: 'calculated_rolling_24h',
      loss_distribution: timeline?.lossDistribution,
      model_status: model?.calibration_status || 'sin_modelo',
      recharge_efficiency_learned: model?.recharge_efficiency != null,
      etc_correction_learned: model?.etc_correction_factor != null,
      probe_capacity_scaled: model?.calibration_diagnostics?.reference_taw_mm > 0,
      probe_transfer_last_clean_day: model?.calibration_diagnostics?.transfer_dynamics?.last_clean_day || null,
      probe_dynamics_learned: model?.calibration_diagnostics?.transfer_dynamics?.revision===2
        ? model.calibration_diagnostics.transfer_dynamics.forecast_usable
        : model?.calibration_diagnostics?.transfer_dynamics?.clean_sample_count > 0,
    },
    // Punto de partida de la curva (fecha + valor en escala de Suma de
    // perfil): el gráfico encuadra su ventana y marca este punto para
    // que la inicialización se vea reflejada.
    anchor_date: anchor.date,
    anchor_storage_mm: round1(wilting + anchor.useful),
    history: withHistory ? history : null,
    events: { irrigation: irrigationEvents, scheduled: scheduledEvents, scheduledPrograms, observed: [...(ctx.observedIrrigation.byLot.get(lot.id)?.values() || [])], rain: rainEvents },
    forecast_status: 'ok',
  };
}

export const lotWaterStateService = {
  // Map<lot_id, estado calculado> — SOLO LECTURA/CÁLCULO: una consulta
  // de UI nunca escribe LotWaterState (los registros se crean únicamente
  // con las inicializaciones explícitas de más abajo). withHistory
  // incluye la serie diaria pasada (para el gráfico).
  async getLotStates(lots, { withHistory = false } = {}) {
    const ctx = await loadContext(lots);
    const results = await Promise.all(lots.map(l => computeLot(l, ctx, withHistory)));
    return new Map(lots.map((l, i) => [l.id, results[i]]));
  },

  // Inicialización manual del estado del lote. La entrada está en la
  // MISMA escala del gráfico "Suma de perfil" (mm de agua almacenada):
  // la curva arranca exactamente en el valor ingresado. Se acota al
  // rango físico [punto de marchitez, capacidad de campo] — el
  // excedente drena y no se almacena. A partir de ahí el estado
  // evoluciona solo con los eventos del lote.
  async initializeManual(lotId, profileWaterMm, date) {
    // La fecha del estado inicial ancla la curva en ese día (hoy o
    // anterior): la reconstrucción arranca ahí y absorbe los riegos
    // ejecutados y la lluvia registrados desde entonces.
    if (date) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > todayStr()) {
        throw new Error('La fecha del estado inicial debe ser hoy o una fecha anterior.');
      }
    }
    const profiles = await backend.entities.SoilProfile.filter({ lot_id: lotId });
    const profile = profiles[0];
    if (!profile) throw new Error('El lote no tiene perfil de suelo configurado.');
    const models = await soilBehaviorService.getModels();
    const config = await soilWaterService.getProfileConfig(profile, await referenceFullDepthCm(profile, models));
    const wilting = config?.wilting_storage_mm || 0;
    const taw = config?.total_available_water_capacity_mm;
    let useful = round1(profileWaterMm - wilting);
    if (taw != null && useful > taw) useful = taw;
    if (useful < 0) useful = 0;
    const stored = round1(wilting + useful);
    await backend.entities.SoilProfile.update(profile.id, { manual_initial_water_mm: useful });
    // Una nueva inicialización REINICIA la curva: se eliminan los
    // estados explícitos previos del lote. Sin esto, una
    // re-inicialización con fecha ANTERIOR perdería contra el registro
    // previo (el ancla se elige por el timestamp más reciente) y el
    // gráfico seguiría mostrando la inicialización vieja.
    const priorStates = await backend.entities.LotWaterState.filter({ lot_id: lotId });
    await Promise.all(priorStates
      .filter(s => s.source === 'manual_adjustment' || s.source === 'initialized')
      .map(s => backend.entities.LotWaterState.delete(s.id)));
    return backend.entities.LotWaterState.create({
      lot_id: lotId,
      timestamp: date ? `${date}T12:00:00-03:00` : new Date().toISOString(),
      profile_water_mm: stored,
      source: 'manual_adjustment',
      model_version: MODEL_VERSION,
    });
  },

};
