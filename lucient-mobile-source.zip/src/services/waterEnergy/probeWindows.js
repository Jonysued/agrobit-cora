// Closed, non-overlapping irrigation cycles. A falling profile alone cannot
// distinguish extraction from drainage; accept only its stable terminal 24 h.
const HOUR = 3600000;
const localDayFormatter = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'America/Argentina/Buenos_Aires', year:'numeric', month:'2-digit', day:'2-digit',
});
const localDay = time => localDayFormatter.format(new Date(time));
export function terminalDrydownWindows(snapshots, { asOf = Date.now() } = {}) {
  const cutoff = Date.parse(`${localDay(asOf)}T00:00:00-03:00`);
  const ordered = snapshots.filter(s => Number.isFinite(s.time) && Number.isFinite(s.mm)
    && s.time < cutoff).sort((a,b) => a.time-b.time);
  const samples = [];
  let cycleStart = null, candidate = null, runStart = 0;
  for (let i = 1; i < ordered.length; i++) {
    const previous = ordered[i-1], end = ordered[i];
    if (end.time - previous.time > 2*HOUR) {
      // A gap does not close an irrigation cycle or certify its last slope.
      cycleStart = null; candidate = null; runStart = i; continue;
    }
    if (end.mm - previous.mm > 0.5) {
      if (candidate && cycleStart != null && end.time-candidate.end<=12*HOUR) samples.push({ ...candidate,
        confirmed_at: end.time, day:localDay(end.time), source:'terminal_window' });
      cycleStart = end.time; candidate = null; continue;
    }
    if (cycleStart == null || end.time - cycleStart < 36*HOUR) continue;
    const at = hours => {
      const target = end.time-hours*HOUR;
      let lo=runStart, hi=i;
      while(lo<hi){const mid=(lo+hi)>>1;if(ordered[mid].time<target)lo=mid+1;else hi=mid;}
      const item=ordered[lo];
      return item && Math.abs(item.time-target)<=HOUR/6 ? item : null;
    };
    const start=at(24), mid=at(12), guard=at(36);
    if (!start || !mid || !guard || guard.time < cycleStart) continue;
    const losses=[guard.mm-start.mm,start.mm-mid.mm,mid.mm-end.mm];
    // Reject accelerating/decelerating drainage and cumulative small rises.
    // Three 12-hour blocks must agree within 50%, with a 0.5 mm noise floor.
    if (Math.min(...losses)<-0.2 || Math.max(...losses)>
      Math.max(0.5,Math.max(0,Math.min(...losses))*1.5)) continue;
    const fall=start.mm-end.mm;
    if (fall < -0.2) continue;
    candidate={start:start.time,end:end.time,loss_mm:Math.round(Math.max(0,fall)*10)/10};
  }
  // Never count repeated overlapping windows, nor an unfinished cycle whose
  // terminal extraction rate is not yet known. Zero drydown is valid.
  return samples;
}
