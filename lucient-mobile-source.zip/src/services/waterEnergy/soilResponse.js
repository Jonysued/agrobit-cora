export function drydownFactor() { return 1; }

// Secado observado o estimado, sin recargas ni drenaje de la sonda.
export function probeProfileLoss(model, { date = null, eto, forecastFactor = null, meanEto = null, lotTaw = null }) {
  const data = model?.calibration_diagnostics?.transfer_dynamics;
  if (!data || ![1, 2].includes(data.version)) return null;
  const sourceTaw = model.calibration_diagnostics.reference_taw_mm;
  const scale = lotTaw > 0 && sourceTaw > 0 ? lotTaw / sourceTaw : 1;
  let loss;
  if (date && forecastFactor == null) {
    loss = data.daily?.find(d => d.day === date)?.loss_mm;
  } else {
    if (data.revision===2 && data.forecast_usable===false) return null;
    const lastDay = data.last_clean_day;
    const asOf = date || model.calibration_diagnostics.last_probe_day;
    const age = lastDay && asOf ? (Date.parse(asOf) - Date.parse(lastDay)) / 86400000 : Infinity;
    if (age > 14 || age < 0) return null;
    loss = data.loss_per_eto != null && Number.isFinite(eto)
      ? data.loss_per_eto * eto
      : data.recent_loss_mm_day == null ? null : data.recent_loss_mm_day * (meanEto > 0 ? eto / meanEto : 1);
  }
  return loss == null || !Number.isFinite(loss) ? null : Math.round(Math.max(0, loss * scale) * 10) / 10;
}

// Las recargas propias suman agua; no reinician el drenaje de otra parcela.
export function forecastDrydownFactor() { return 1; }
export function afterRiseFactor() { return 1; }


const median = values => {
  if (!values.length) return null;
  const ordered = [...values].sort((a, b) => a - b);
  const middle = Math.floor(ordered.length / 2);
  return ordered.length % 2 ? ordered[middle] : (ordered[middle - 1] + ordered[middle]) / 2;
};
const dayGap = (a, b) => (Date.parse(a) - Date.parse(b)) / 86400000;

// Only a recharge belonging to this lot can restart its response cycle.
// Phase zero is the point receiving water; phase one is the following day.
export function advanceLotCycle(cycle, rechargeMm = 0) {
  if (Number.isFinite(rechargeMm) && rechargeMm > 0) {
    return { phase: 0, rechargeMm };
  }
  return { phase: cycle?.phase == null ? null : cycle.phase + 1,
    rechargeMm: cycle?.rechargeMm ?? 0 };
}

// Reconstruct phase statistics from data available BEFORE the calculated
// day. For forecasts the server's intraday cycle statistics are preferred.
// The probe's current phase and recharge dates never become lot events.
export function lotCycleLoss(model, { date, eto, meanEto = null,
  cycle = null, learningThrough = null } = {}) {
  const diagnostics = model?.calibration_diagnostics;
  const data = diagnostics?.transfer_dynamics;
  if (!data || !date) return null;
  const cutoff = learningThrough ?? diagnostics.last_probe_day;
  const profile = (data.daily_profile || []).filter(d => Number.isFinite(d.mm)
    && (!cutoff || d.day <= cutoff)).sort((a, b) => a.day.localeCompare(b.day));
  const lastSource = profile.at(-1)?.day ?? diagnostics.last_probe_day;
  if (!lastSource || dayGap(date, lastSource) > 14 || dayGap(date, lastSource) < 0) return null;
  const historical = learningThrough && learningThrough < diagnostics.last_probe_day;
  const confirmedThrough = Date.parse(`${cutoff}T23:59:59.999-03:00`);
  const cleanDays = (data.daily || []).filter(d => d.source === 'observed'
    && Number.isFinite(d.loss_mm) && d.day <= cutoff && dayGap(cutoff, d.day) <= 14);
  // A window becomes evidence at confirmation, not at its earlier end.
  // Estimated daily rows derived from it are not additional samples.
  const windows = (data.clean_windows || []).filter(w => Number.isFinite(w.loss_mm)
    && Number.isFinite(w.confirmed_at) && w.confirmed_at <= confirmedThrough
    && w.day <= cutoff && dayGap(cutoff, w.day) <= 14);
  const clean = [...cleanDays, ...windows].sort((a, b) => a.day.localeCompare(b.day)).slice(-7);
  const usable = cleanDays.length > 0 || windows.length >= 2;
  let baseline = historical ? (usable ? median(clean.map(d => d.loss_mm)) : null) : data.recent_loss_mm_day;
  if (!historical && data.forecast_usable === false) baseline = null;
  const climaticBaseline = baseline == null ? null : Math.max(0,
    !historical && Number.isFinite(data.loss_per_eto) && Number.isFinite(eto)
      ? data.loss_per_eto * eto : baseline * (meanEto > 0 && Number.isFinite(eto) ? eto / meanEto : 1));
  let phases = diagnostics.drydown_cycle || [];
  if (historical || profile.length > 1) {
    const buckets = new Map();
    let phase = null;
    for (let i = 1; i < profile.length; i++) {
      const prev = profile[i - 1], current = profile[i];
      if (dayGap(current.day, prev.day) !== 1) { phase = null; continue; }
      const fall = prev.mm - current.mm;
      if (fall < -0.5) { phase = 0; continue; }
      if (phase == null) continue;
      phase++;
      const evidence = data.daily?.find(d => d.day === current.day);
      // A net daily fall can conceal an intraday recharge. It must not
      // teach a depletion rate. Nor may today's partial close teach one.
      if (evidence?.excluded_reason === 'probe_recharge') { phase = 0; continue; }
      if (data.last_completed_day && current.day > data.last_completed_day) continue;
      if (fall >= 0 && phase <= 15 && dayGap(cutoff, current.day) <= 14) {
        // Use the most recently completed matching phase. A median of all
        // old cycles was flattening the current probe response indefinitely.
        buckets.set(phase, { day: phase, fall_mm: Math.round(fall * 10) / 10, observed_day: current.day });
      }
    }
    const recentPhases = [...buckets.values()];
    phases = historical ? recentPhases : [
      ...recentPhases, ...phases.filter(p => !buckets.has(p.day)),
    ];
  }
  const learned = cycle?.phase > 0
    ? phases.find(p => p.day === cycle.phase && Number.isFinite(p.fall_mm)) : null;
  let loss = climaticBaseline;
  if (learned) {
    // Preserve the measured cycle in mm. Do not multiply the whole fall by
    // Kc or by a guessed ratio of soil capacities. Bounds belong to the lot.
    // Scale only the additional early fall for a smaller NET lot recharge;
    // no extrapolation above the observed reference response.
    const rises = [];
    for (let i = 1; i < profile.length; i++) {
      if (dayGap(profile[i].day, profile[i - 1].day) !== 1) continue;
      const rise = profile[i].mm - profile[i - 1].mm;
      if (rise > 0.5) rises.push(rise);
    }
    const typicalRise = median(rises);
    const magnitude = typicalRise > 0 && cycle.rechargeMm > 0
      ? Math.min(1, cycle.rechargeMm / typicalRise) : 1;
    const referenceBase = baseline ?? learned.fall_mm;
    loss = (climaticBaseline ?? learned.fall_mm)
      + Math.max(0, learned.fall_mm - referenceBase) * magnitude
      - Math.max(0, referenceBase - learned.fall_mm);
  }
  return Number.isFinite(loss) ? Math.round(Math.max(0, loss) * 10) / 10 : null;
}
