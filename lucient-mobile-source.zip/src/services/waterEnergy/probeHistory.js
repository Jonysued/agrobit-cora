// Compact transport only: retain every channel, timestamp and value.
// No averaging or downsampling may hide a recharge or change a 24 h delta.
export function unpackProbeHistory(payload, probeId) {
  if (payload?.version !== 1 || !Array.isArray(payload.rows)) throw new Error('Historial de sonda inválido.');
  return payload.rows.map(([id, probe_channel_id, timestamp, value, depth_cm, unit, source, quality_status]) =>
    ({ id, probe_id: probeId, probe_channel_id, timestamp, value, depth_cm, unit, source, quality_status }));
}
