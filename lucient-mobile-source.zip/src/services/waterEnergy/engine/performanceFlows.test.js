import test from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import path from 'node:path';
import { unpackProbeHistory } from '../probeHistory.js';
import { measuredProbeProfile } from './measuredProbeProfile.js';

test('compact history retains every measurement, recharge and exact 24 h change', () => {
  const channels = [10, 30, 60].map(depth => ({ id: `c${depth}`, depth_cm: depth, sensor_type: 'soil_moisture' }));
  const rows = Array.from({ length: 97 }, (_, index) => channels.map(channel => ({
    id: `${index}-${channel.id}`, probe_id: 'p', probe_channel_id: channel.id,
    timestamp: new Date(Date.parse('2026-10-01T00:00Z') + index * 1800000).toISOString(),
    value: 25 - index / 100 + (index >= 50 ? 8 : 0), depth_cm: channel.depth_cm,
    unit: '%', source: 'LIVE', quality_status: 'ok',
  }))).flat();
  const packed = { version: 1, rows: rows.map(r => [r.id, r.probe_channel_id, r.timestamp, r.value, r.depth_cm, r.unit, r.source, r.quality_status]) };
  const restored = unpackProbeHistory(JSON.parse(JSON.stringify(packed)), 'p');
  assert.deepEqual(restored, rows);
  assert.deepEqual(measuredProbeProfile(channels, restored), measuredProbeProfile(channels, rows));
  assert.throws(() => unpackProbeHistory({ version: 2, rows: [] }, 'p'), /inválido/);
});

test('current Dashboard resolves while forecast waits, shares calculation and clears on auth change', async () => {
  const bundle = await build({ entryPoints: ['src/services/waterEnergy/waterForecastService.js'], bundle: true, platform: 'node', format: 'esm', treeShaking: false, write: false,
    plugins: [{ name: 'flow-fixture', setup(b) {
      b.onResolve({ filter: /backendClient|weatherService|lotWaterStateService|energyService|monitoringService/ }, () => ({ path: 'fixture', namespace: 'test' }));
      b.onLoad({ filter: /.*/, namespace: 'test' }, () => ({ contents: `
        let resolveWeather, calls = 0, reset;
        const lot = { id: 'l', name: 'L' };
        export const fixture = { release: () => resolveWeather(new Map()), calls: () => calls, reset: () => reset() };
        export const supabase = { auth: { onAuthStateChange: fn => { reset = fn; } } };
        export const backend = { entities: new Proxy({}, { get: (_, name) => ({ list: async () => name === 'Lot' ? [lot] : [] }) }) };
        export const lotWaterStateService = { getLotStates: async () => { calls++; return new Map([['l', { forecast_status: 'ok', profile: null, config: { configuration_status: 'complete', total_available_water_capacity_mm: 100 }, currentUsefulMm: 40, currentStoredMm: 100 }]]); } };
        export const weatherService = { getFarmForecast: () => new Promise(resolve => { resolveWeather = resolve; }) };
        export const monitoringService = { devices: async () => [] };
        export const energyService = { getPumps: async () => [], getTariffs: async () => [], projectionWindow: () => ({ start: 0 }), getActiveTariff: () => ({}), getRecommendedOverview: () => ({}) };
      `, loader: 'js' }));
      b.onResolve({ filter: /^@\// }, args => ({ path: path.resolve('src', args.path.slice(2) + '.js') }));
    } }],
  });
  // Export the injected dependency through a second virtual entry, rather
  // than relying on private browser state or real network credentials.
  const code = bundle.outputFiles[0].text.replace('export {', 'export { fixture,');
  const { waterForecastService: service, fixture } = await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));
  let done = false;
  const forecast = service.getFarmOverview().then(value => { done = true; return value; });
  const current = await service.getCurrentOverview();
  assert.equal(current.rows[0].state.current_available_water_mm, 40);
  assert.equal(done, false);
  assert.equal(fixture.calls(), 1);
  fixture.release();
  await forecast;
  assert.equal(fixture.calls(), 1);
  fixture.reset();
  await service.getCurrentOverview();
  assert.equal(fixture.calls(), 2);
});

test('compact probe service uses one request and preserves pending offline edits', async () => {
  const bundle = await build({ entryPoints: ['src/services/waterEnergy/sensorService.js'], bundle: true, platform: 'node', format: 'esm', write: false,
    plugins: [{ name: 'history-fixture', setup(b) {
      b.onResolve({ filter: /^@\/api\/backendClient$/ }, () => ({ path: 'backend', namespace: 'history' }));
      b.onResolve({ filter: /^@\/lib\/offline$/ }, () => ({ path: 'offline', namespace: 'history' }));
      b.onLoad({ filter: /.*/, namespace: 'history' }, args => ({ contents: args.path === 'backend' ? `
        export const backend = { entities: { SensorReading: { filterAll: () => { throw Error('unnecessary paginated download'); } } } };
        export const supabase = { rpc: async (name, args) => {
          if (name !== 'probe_readings_range' || args.p_probe_id !== 'p') throw Error('wrong RPC');
          return { data: { version: 1, rows: [['a','c','2026-10-01T00:00:00Z',20,10,'%','LIVE','ok'],['b','c','2026-10-02T00:00:00Z',21,10,'%','LIVE','ok']] } };
        } };
      ` : `
        export { overlay, matches } from ${JSON.stringify(path.resolve('src/lib/offline.js'))};
        let saved;
        export const snapshot = async (_, load) => saved || (saved = await load());
        export const pendingOperations = async () => [
          {table:'sensor_readings',kind:'entity',operation:'update',id:'a',payload:{value:25}},
          {table:'sensor_readings',kind:'entity',operation:'delete',id:'b'},
          {table:'sensor_readings',kind:'entity',operation:'create',id:'c',payload:{probe_id:'other',timestamp:'2026-10-01T00:00:00Z',value:90}}
        ];
      `, loader: 'js', resolveDir: process.cwd() }));
    } }],
  });
  const { sensorService } = await import('data:text/javascript;base64,' + Buffer.from(bundle.outputFiles[0].text).toString('base64'));
  const rows = await sensorService.getProbeReadings('p', '2026-10-01T00:00:00Z', '2026-10-03T00:00:00Z');
  assert.equal(rows.length, 1);
  assert.equal(rows[0].value, 25);
  assert.equal(rows[0]._offline_pending, true);
  assert.deepEqual(await sensorService.getProbeReadings('p', '2026-10-01T00:00:00Z', '2026-10-03T00:00:00Z'), rows);
  assert.equal((await sensorService.getProbeReadings('p', '2026-09-30T00:00:00Z', '2026-10-01T00:00:00.000Z')).length, 1);
});
