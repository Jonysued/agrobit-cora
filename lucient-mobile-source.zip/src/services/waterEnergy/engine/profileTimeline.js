const DAY = 86400000;
const round1 = value => Math.round(value * 10) / 10;
const dayKey = time => new Date(time - 3 * 3600000).toISOString().slice(0, 10);

// Estimate storage on one continuous time axis. Rain is an observed
// increment; irrigation is delivered over its recorded interval. Daily
// model loss is distributed uniformly inside the day (an estimate).
// Midnight and the rolling cutoff are checkpoints, never water inputs.
export function reconstructProfile({ start, end, initialMm, capacityMm,
  dailyLoss = new Map(), deliveries = [], rain = [] }) {
  if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) return null;
  const cutoff = end - DAY;
  const boundaries = new Set([start, end]);
  if (cutoff >= start) boundaries.add(cutoff);
  let midnight = Date.parse(`${dayKey(start)}T00:00:00-03:00`) + DAY;
  while (midnight < end) { boundaries.add(midnight); midnight += DAY; }
  const inputs = deliveries.filter(d => d.end > start && d.start < end && d.mmPerHour >= 0);
  for (const d of inputs) { boundaries.add(Math.max(start, d.start)); boundaries.add(Math.min(end, d.end)); }
  const rainAt = new Map();
  for (const r of rain) {
    // The initial storage already contains events at or before the anchor.
    if (!(r.time > start && r.time <= end && r.mm > 0)) continue;
    boundaries.add(r.time);
    rainAt.set(r.time, (rainAt.get(r.time) || 0) + r.mm);
  }
  const times = [...boundaries].sort((a, b) => a - b);
  const bound = value => Math.max(0, Math.min(capacityMm ?? Infinity, value));
  let water = bound(initialMm);
  const values = new Map([[start, water]]);
  for (let i = 1; i < times.length; i++) {
    const a = times[i - 1], b = times[i];
    const rate = inputs.filter(d => d.start <= a && d.end >= b).reduce((sum, d) => sum + d.mmPerHour, 0);
    const loss = Math.max(0, dailyLoss.get(dayKey(a)) || 0);
    water = bound(water + rate * (b - a) / 3600000 - loss * (b - a) / DAY);
    water = bound(water + (rainAt.get(b) || 0));
    values.set(b, water);
  }
  const history = [{ date: dayKey(start), mm: round1(values.get(start)) }];
  for (const [time, value] of values) {
    if (time <= start || time === end || (time + 0) % DAY !== 3 * 3600000) continue;
    history.push({ date: dayKey(time), mm: round1(value) });
  }
  const last = { date: dayKey(end), mm: round1(water) };
  if (history.at(-1).date === last.date) history[history.length - 1] = last;
  else history.push(last);
  return { currentMm: round1(water), history,
    change24h: values.has(cutoff) ? round1(water - values.get(cutoff)) : null,
    cutoff, lossDistribution: 'uniform_within_day' };
}
