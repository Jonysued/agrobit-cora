import test from 'node:test';
import assert from 'node:assert/strict';
import { reconstructProfile } from './profileTimeline.js';
const t=Date.parse;
const base={start:t('2026-10-12T12:00:00-03:00'),end:t('2026-10-14T12:00:00-03:00'),
 initialMm:50,capacityMm:200,dailyLoss:new Map(['2026-10-12','2026-10-13','2026-10-14'].map(d=>[d,2]))};
test('rain older than 24 hours changes storage but not the rolling increase',()=>{
 const result=reconstructProfile({...base,rain:[{time:t('2026-10-13T07:00:00-03:00'),mm:17.5}]});
 assert.equal(result.currentMm,63.5);
 assert.equal(result.change24h,-2);
});
test('rain inside the rolling window is counted once, including across midnight',()=>{
 const result=reconstructProfile({...base,rain:[{time:t('2026-10-13T23:00:00-03:00'),mm:7}]});
 assert.equal(result.change24h,5);
 assert.equal(result.currentMm,53);
});
test('actual irrigation overlapping the cutoff contributes only delivered hours',()=>{
 const result=reconstructProfile({...base,deliveries:[{start:t('2026-10-13T10:00:00-03:00'),end:t('2026-10-13T14:00:00-03:00'),mmPerHour:2}]});
 assert.equal(result.currentMm,54);
 assert.equal(result.change24h,2);
});
test('a new anchor cannot pretend to have a full day of history',()=>{
 assert.equal(reconstructProfile({...base,start:base.end-3600000}).change24h,null);
});
test('loss before a rain event cannot be applied after saturation',()=>{
 const r=reconstructProfile({...base,initialMm:199,rain:[{time:base.end-3600000,mm:10}]});
 assert.equal(r.currentMm,199.9);
});
