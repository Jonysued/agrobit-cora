import { test } from 'node:test';
import assert from 'node:assert/strict';
import { addProbeOverlay, hoverPoint } from '../../../components/waterEnergy/profileChartHover.js';
const ts = day => new Date(`${day}T12:00:00`).getTime();

test('probe overlay shares daily and irrigation-jump rows without moving future tooltip values', () => {
  const points = [
    { t: ts('2026-10-14'), Histórico: 402.5 },
    { t: ts('2026-10-15') - 43200000, Histórico: 410 },
    { t: ts('2026-10-15'), Histórico: 405 },
    { t: ts('2026-10-16'), Histórico: 400, Futuro: 400 },
    { t: ts('2026-10-17'), Histórico: null, Futuro: 395 },
  ];
  const { data, keys } = addProbeOverlay(points, [{ day: '2026-10-14', mm: 420 }, { day: '2026-10-15', mm: 413 }], 'Sonda', true);
  assert.deepEqual(data.map(p => p.t), points.map(p => p.t));
  assert.equal(keys.length, 1);
  assert.equal(hoverPoint(data, ts('2026-10-17')).Histórico, null);
  assert.equal(hoverPoint(data, ts('2026-10-17')).Futuro, 395);
  assert.equal(hoverPoint(data, ts('2026-10-17')).Sonda, null);
  assert.equal(hoverPoint(data, ts('2026-10-14')).Sonda, 420);
  assert.equal(data[1].Sonda, null); // never invent a reading at an irrigation jump
  assert.equal(hoverPoint(data, null), null);
  assert.equal(hoverPoint(data, ts('2026-10-18')), null);
  assert.equal(points[0].Sonda, undefined); // original calculations unchanged
});

test('missing probe days break the measured curve, while intermediate jump rows do not', () => {
  const points = ['2026-10-14', '2026-10-15', '2026-10-16', '2026-10-17'].map(day => ({ t: ts(day) }));
  const history = [{ day: '2026-10-14', mm: 420 }, { day: '2026-10-15', mm: 413 }, { day: '2026-10-17', mm: 400 }];
  const { data, keys } = addProbeOverlay(points, history, 'Sonda', true);
  assert.equal(keys.length, 2);
  assert.equal(data[0][keys[0]], 420);
  assert.equal(data[1][keys[0]], 413);
  assert.equal(data[3][keys[0]], undefined);
  assert.equal(data[3][keys[1]], 400);
  assert.equal(data[2].Sonda, null);
  assert.deepEqual(addProbeOverlay(points, history, 'Sonda', false).keys, []);
});
