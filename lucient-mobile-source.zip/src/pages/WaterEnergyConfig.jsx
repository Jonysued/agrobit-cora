import React, { useEffect, useState } from 'react';
import LoadingState from '@/components/LoadingState';
import { waterForecastService, sensorService, energyService, weatherService, soilBehaviorService } from '@/services/waterEnergy';
import ProfileSection from '@/components/waterEnergy/config/ProfileSection';
import SensorSection from '@/components/waterEnergy/config/SensorSection';
import PumpSection from '@/components/waterEnergy/config/PumpSection';
import TariffSection from '@/components/waterEnergy/config/TariffSection';
import LinkSection from '@/components/waterEnergy/config/LinkSection';
import FarmLocationSection from '@/components/waterEnergy/config/FarmLocationSection';
import WeatherSourceSection from '@/components/waterEnergy/config/WeatherSourceSection';
import WeatherStationSection from '@/components/waterEnergy/config/WeatherStationSection';
import { useIsMobile } from '@/hooks/use-mobile';
import { MobileDisclosure } from '@/components/mobile/MobileUI';

export default function WaterEnergyConfig({ embedded = false }) {
  const mobile = useIsMobile();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const refresh = async () => {
    const lots = await waterForecastService.getLots();
    const [profiles, probes, pumps, tariffs, weather] = await Promise.all([
      waterForecastService.getProfiles(),
      sensorService.getProbes(),
      energyService.getPumps(),
      energyService.getTariffs(),
      weatherService.getConfig(lots.map(l => l.farm)),
    ]);
    // SOLO LECTURA: abrir Configuración no crea ni recalibra modelos
    // de suelo (la calibración es una acción explícita en
    // Vinculación de perfiles).
    const models = await soilBehaviorService.getModels();
    setData({ lots, profiles, probes, models, pumps, tariffs, farms: weather.farms, stations: weather.stations });
  };
  useEffect(() => { refresh().catch(() => setError(true)); }, []);
  if (!data) return error ? <div className="p-6 text-sm text-slate-500">No se pudo cargar la configuración.</div> : <LoadingState />;
  if (mobile) return <div className="mt-5"><h2>Agua y energía</h2><p className="mobile-subtitle">Configuraciones agrupadas.</p><MobileDisclosure title="Suelos y humedad inicial"><ProfileSection lots={data.lots} profiles={data.profiles} onChange={refresh}/></MobileDisclosure><MobileDisclosure title="Sondas y vinculación"><SensorSection lots={data.lots} probes={data.probes} profiles={data.profiles} models={data.models} onChange={refresh}/><LinkSection lots={data.lots} profiles={data.profiles} probes={data.probes} models={data.models} pumps={data.pumps} onChange={refresh}/></MobileDisclosure><MobileDisclosure title="Pozos, bombas y tarifas"><PumpSection lots={data.lots} pumps={data.pumps} onChange={refresh}/><TariffSection tariffs={data.tariffs} onChange={refresh}/></MobileDisclosure><MobileDisclosure title="Fincas y fuentes meteorológicas"><FarmLocationSection lots={data.lots} farms={data.farms} onChange={refresh}/><WeatherSourceSection lots={data.lots} farms={data.farms} stations={data.stations} onChange={refresh}/><WeatherStationSection farms={data.farms} stations={data.stations} onChange={refresh}/></MobileDisclosure></div>;
  return (
    <div className={embedded ? "space-y-5" : "mx-auto max-w-[1200px] space-y-5 p-4 md:p-6"}>
      <div>
        <h2 className="text-xl font-bold text-charcoal">Configuración de Water &amp; Energy</h2>
        <p className="mt-1 text-sm text-slate-500">Perfiles de suelo, sondas, bombas, tarifas y fuentes meteorológicas.</p>
      </div>
      <div className="space-y-5">
        <ProfileSection lots={data.lots} profiles={data.profiles} onChange={refresh} />
        <SensorSection lots={data.lots} probes={data.probes} profiles={data.profiles} models={data.models} onChange={refresh} />
        <PumpSection lots={data.lots} pumps={data.pumps} onChange={refresh} />
        <TariffSection tariffs={data.tariffs} onChange={refresh} />
        <LinkSection lots={data.lots} profiles={data.profiles} probes={data.probes} models={data.models} pumps={data.pumps} onChange={refresh} />
        <FarmLocationSection lots={data.lots} farms={data.farms} onChange={refresh} />
        <WeatherSourceSection lots={data.lots} farms={data.farms} stations={data.stations} onChange={refresh} />
        <WeatherStationSection farms={data.farms} stations={data.stations} onChange={refresh} />
      </div>
    </div>
  );
}
