import React from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useFarm } from '@/lib/FarmContext';
import { lotMetrics } from '@/lib/farmCalculations';
import { MobileMore, MobilePage, mobileNumber, useMobileFarm } from '@/components/mobile/MobileUI';
export default function More() {
  const [params] = useSearchParams(), d = useFarm(), { farm } = useMobileFarm();
  if (!params.get('objetivos')) return <MobileMore params={params} />;
  const lots = d.Lot.filter(l => !farm || l.farm === farm);
  return <MobilePage title="Objetivos y producción" back={{ to: '/mas', label: 'Más' }} subtitle="Últimos objetivos registrados por lote."><div className="mobile-card">{lots.map(l => { const m = lotMetrics(l, d.ProductionRecord, d.Objective, d.HealthRecord); return <Link to={`/lotes/${l.id}`} key={l.id} className="mobile-state-row"><span>{l.name}</span><b>{m.objective?.kg_ha > 0 ? `${mobileNumber(m.objective.kg_ha / 1000)} t/ha` : 'Sin objetivo'}</b></Link>; })}{!lots.length && <p className="mobile-muted">No hay lotes para esta selección.</p>}</div></MobilePage>;
}
