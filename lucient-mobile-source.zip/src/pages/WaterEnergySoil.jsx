import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, Gauge } from 'lucide-react';
import ModuleHeader from '@/components/waterEnergy/ModuleHeader';
import LoadingState from '@/components/LoadingState';
import { soilWaterService, CONFIG_LABELS } from '@/services/waterEnergy';
import { useIsMobile } from '@/hooks/use-mobile';
import { MobileRow } from '@/components/mobile/MobileUI';

// SENSORES — pantalla principal: una sonda por tarjeta,
// solo información de monitoreo del perfil de suelo.
const STATUS_TEXT = { RECARGAR: 'text-red-600', ÓPTIMO: 'text-emerald-700', LLENO: 'text-cyan-700' };
const SOURCE_BADGE = {
  LIVE: 'bg-emerald-100 text-emerald-800',
  CSV: 'bg-blue-100 text-blue-800',
  MANUAL: 'bg-slate-100 text-slate-700',
  DEMO: 'bg-amber-100 text-amber-800',
};

const rel = ts => {
  if (!ts) return '—';
  const h = Math.round((Date.now() - new Date(ts).getTime()) / 3600000);
  return h < 1 ? 'hace instantes' : h < 48 ? `hace ${h} h` : `hace ${Math.round(h / 24)} días`;
};
const missingLabels = row => (row.missing_configuration || []).map(k => CONFIG_LABELS[k] || k).join(', ');

export default function WaterEnergySoil({ embedded = false }) {
  const mobile = useIsMobile();
  const nav = useNavigate();
  const [rows, setRows] = useState(null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    let cancelled = false, pending = false;
    const refresh = async () => {
      if (pending) return;
      pending = true;
      try { const next = await soilWaterService.getProbeSummaries(); if (!cancelled) { setRows(next); setErr(false); } }
      catch { if (!cancelled) setErr(true); }
      finally { pending = false; }
    };
    void refresh(); const timer = setInterval(refresh, 60000);
    return () => { cancelled = true; clearInterval(timer); };
  }, []);
  if (!rows) return err ? <div className="p-6 text-sm text-slate-500">No se pudo cargar los sensores.</div> : <LoadingState />;
  if (mobile) return <><p className="mobile-subtitle">Últimas lecturas y estado de conexión.</p>{err&&<p className="mobile-note" role="alert">No se pudo actualizar. Se conservan las últimas lecturas descargadas.</p>}<div className="mobile-card mobile-menu">{rows.map(r=><MobileRow key={r.probe.id} icon={Gauge} title={r.probe.name} to={`/riego?tab=sensores&sonda=${encodeURIComponent(r.probe.id)}`} detail={`${r.lastReadingAt?rel(r.lastReadingAt):'Sin lectura'} · ${r.missing||r.connectionStatus==='disconnected'?'Revisar conexión':'Ver perfil medido'}`} />)}{!rows.length&&<p className="mobile-muted py-4">Todavía no hay sondas configuradas.</p>}</div><MobileRow to="/clima" icon={Gauge} title="Estación meteorológica" detail="Temperatura, lluvia y ET0"/></>;
  return (
    <div className={embedded ? "space-y-5" : "mx-auto max-w-[1600px] space-y-5 p-4 md:p-6"}>
      {!embedded && <ModuleHeader />}
      <div>
        <h2 className="text-lg font-bold text-charcoal">Sensores</h2>
        <p className="text-xs text-slate-500">Mediciones de cada sonda, incluso antes de vincularla a un lote.</p>
      </div>
      {err && <p role="alert" className="text-sm text-amber-800">No se pudo actualizar. Se muestran las últimas lecturas descargadas.</p>}
      {!rows.length ? (
        <div className="rounded-2xl border border-black/5 bg-white p-10 text-center shadow-sm">
          <Gauge className="mx-auto text-slate-300" size={32} />
          <p className="mt-3 text-sm font-semibold text-charcoal">Todavía no hay sondas configuradas</p>
          <p className="mt-1 text-xs text-slate-500">Registrá y sincronizá la sonda en Configuración → Water & Energy → Sensores.</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {rows.map(row => (
            <button key={row.probe.id} type="button" onClick={() => nav(`/riego?tab=sensores&sonda=${encodeURIComponent(row.probe.id)}`)} className="rounded-2xl border border-black/5 bg-white p-5 text-left shadow-sm transition hover:shadow-md">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="truncate font-bold text-charcoal">{row.probe.name}</p>
                  <p className="text-xs text-slate-500">{row.lotName}</p>
                </div>
                <div className="flex shrink-0 items-center gap-1.5">
                  {row.connectionStatus === 'disconnected' && <span className="rounded-full bg-red-100 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-red-700">Desconectada</span>}
                  <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide ${SOURCE_BADGE[row.source] || SOURCE_BADGE.MANUAL}`}>{row.source === 'LIVE' ? 'Lectura remota' : row.source}</span>
                </div>
              </div>
              {row.missing ? (
                <p className="mt-5 text-xs text-slate-400">{row.missing}</p>
              ) : row.configuration_status === 'unlinked' ? (
                <div className="mt-5">
                  <p className="text-3xl font-bold tracking-tight text-charcoal">{row.total_profile_water_mm ?? '—'} mm</p>
                  <p className="mt-2 text-xs text-slate-500">Suma medida del perfil · 0–{row.measured_profile_depth_cm} cm</p>
                  <p className="mt-1 text-xs text-slate-500">Última lectura: {rel(row.lastReadingAt)}</p>
                </div>
              ) : row.current_available_water_mm == null ? (
                <div className="mt-5">
                  <p className="text-sm font-semibold text-amber-700">Configuración incompleta</p>
                  <p className="mt-1 text-xs text-slate-400">Falta configurar: {missingLabels(row)} — Configuración → Water & Energy.</p>
                </div>
              ) : (
                <>
                  <div className="mt-4 flex items-end justify-between">
                    <span className={`text-3xl font-bold tracking-tight ${STATUS_TEXT[row.status] || 'text-charcoal'}`}>{row.total_profile_water_mm} mm</span>
                    <span className="pb-1 text-[9px] font-bold uppercase tracking-wider text-slate-400">agua en el perfil · 0–{row.measured_profile_depth_cm ?? row.root_zone_depth_cm} cm</span>
                  </div>
                  <div className="mt-3 space-y-1 border-t border-slate-100 pt-3 text-xs text-slate-600">
                    <p>Estado de la última lectura: <b>{row.status || 'Sin configurar'}</b></p>
                    <p>Agua útil del perfil: <b>{row.current_available_water_mm} mm</b></p>
                    <p>Déficit hasta objetivo: <b>{row.water_deficit_mm != null ? `${row.water_deficit_mm} mm` : 'Sin configurar'}</b></p>
                    <p>Última lectura: <b>{rel(row.lastReadingAt)}</b> · {row.lastReadingAt ? new Date(row.lastReadingAt).toLocaleString('es-AR', { timeZone: 'America/Argentina/Buenos_Aires' }) : 'Sin lectura'}</p>
                    {row.missing_configuration?.length > 0 && <p className="text-amber-700">Falta configurar: {missingLabels(row)}</p>}
                  </div>
                </>
              )}
              <span className="mt-4 inline-flex items-center gap-1 text-[11px] font-bold text-emerald-900">Ver detalle <ChevronRight size={12} /></span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
