import InitialMoistureNotice from '@/components/waterEnergy/InitialMoistureNotice';
import { monitoringService } from '@/services/irrigation/monitoringService';
import React, { useEffect, useState } from 'react';
import { backend } from '@/api/backendClient';
import ModuleHeader from '@/components/waterEnergy/ModuleHeader';
import MetricCard from '@/components/MetricCard';
import LoadingState from '@/components/LoadingState';
import { waterForecastService, energyService } from '@/services/waterEnergy';
import { useIsMobile } from '@/hooks/use-mobile';
import MobileEnergy from '@/components/mobile/MobileEnergy';

const formatNumber = value => value == null ? 'Sin datos suficientes' : value.toLocaleString('es-AR', { maximumFractionDigits: 1 });
const formatHours = hours => hours == null ? 'Pendiente' : `${formatNumber(hours)} h`;
const formatKwh = value => value == null ? '—' : `${formatNumber(value)} kWh`;
const formatCost = value => value == null ? '—' : `$ ${value.toLocaleString('es-AR', { maximumFractionDigits: 0 })}`;

export default function WaterEnergyEnergy() {
  const mobile = useIsMobile();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);
  useEffect(() => {
    const change = () => setReloadKey(k => k + 1);
    const stop = monitoringService.subscribe(change);
    const unsubscribe = backend.entities.IrrigationProgram.subscribe(change);
    window.addEventListener('lucient:data-mutated', change);
    const timer = setInterval(change, 60000);
    return () => { stop(); unsubscribe(); clearInterval(timer); window.removeEventListener('lucient:data-mutated', change); };
  }, []);
  useEffect(() => {
    let cancelled = false;
    setError(null);
    (async () => {
      const [overview, pumps, programs] = await Promise.all([
        waterForecastService.getFarmOverview({ force: true }), energyService.getPumps(), backend.entities.IrrigationProgram.list(),
      ]);
      const window = energyService.projectionWindow();
      const scheduled = energyService.getScheduledOverview(programs, pumps, overview.rows, overview.tariff, window);
      const recommended = energyService.getRecommendedOverview(overview.turns, window, overview.tariff, pumps);
      const observed = await monitoringService.observed(overview.rows.map(r => r.lot), []);
      const recorded = energyService.getRecordedOverview(observed, pumps, overview.tariff);
      if (!cancelled) setData({ scheduled, recommended, recorded, pumps, turns: overview.turns });
    })().catch(() => { if (!cancelled) setError(true); });
    return () => { cancelled = true; };
  }, [reloadKey]);
  if (!data) return error ? <div className="p-6 text-sm text-slate-500">No se pudo cargar la sección Energía.</div> : <LoadingState />;
  const { scheduled, recommended, recorded, pumps, turns } = data;
  if (mobile) return <MobileEnergy data={data} error={error}/>;
  return (
    <div className="mx-auto max-w-[1400px] space-y-5 p-4 md:p-6">
      <ModuleHeader energy />
      <InitialMoistureNotice />
      <section className="space-y-3 rounded-2xl border bg-white p-4">
        <h2 className="text-lg font-bold text-charcoal">Funcionamiento registrado · últimos 7 días</h2>
        <p className="text-xs text-slate-500">Horas de encendido de los pozos según Monitoreo. El consumo se estima con su potencia; se cuenta cada pozo una sola vez, aunque abastezca varios lotes. Los equipos sin cierre registrado siguen en curso.</p>
        <div className="grid gap-3 sm:grid-cols-3">
          <MetricCard label="Horas registradas" value={formatHours(recorded.totalHours)} tone="light" />
          <MetricCard label="Consumo estimado" value={formatKwh(recorded.totalKwh)} tone="light" />
          <MetricCard label="Costo estimado" value={formatCost(recorded.totalCost)} tone="dark" />
        </div>
      </section>
      <div className="grid gap-5 lg:grid-cols-2">
        {[{ title: 'Energía programada', energy: scheduled, description: 'Riegos agendados · próximos 7 días. Los horarios superpuestos del mismo pozo se cuentan una sola vez.' },
          { title: 'Energía recomendada', energy: recommended, description: 'Riego adicional sugerido por el modelo · próximos 7 días. No está agendado; cada turno se cuenta una vez por pozo y respeta los horarios programados.' }].map(({ title, energy, description }) => (
          <section key={title} className="space-y-3">
            <h2 className="text-lg font-bold text-charcoal">{title}</h2>
            <p className="text-xs leading-relaxed text-slate-500">{description}</p>
            <div className="grid gap-3 sm:grid-cols-3">
              <MetricCard label="Horas" value={formatHours(energy.totalHours)} tone="light" />
              <MetricCard label="Consumo estimado" value={formatKwh(energy.totalKwh)} tone="light" />
              <MetricCard label="Costo estimado" value={formatCost(energy.totalCost)} tone="dark" />
            </div>
          </section>
        ))}
      </div>
      {scheduled.incompletePrograms > 0 && <p role="status" className="rounded-xl bg-amber-50 p-3 text-sm text-amber-800">Hay {scheduled.incompletePrograms} programa(s) sin pozo, horario o duración válidos. No están incluidos en la energía programada.</p>}
      {(recommended.unavailableTurns > 0 || recommended.incompletePrograms > 0) && <p role="status" className="rounded-xl bg-amber-50 p-3 text-sm text-amber-800">Hay turnos sin disponibilidad confirmada o bomba vinculada. El total recomendado queda pendiente hasta completar esos datos.</p>}
      {pumps.some(p => !(p.flow_m3_h > 0)) && <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-800">Falta el caudal medido de algunos pozos. Cargalo en Configuración → Energy. No se estima kWh/m³ sin ese dato; las horas y kWh pueden calcularse con duración y potencia.</p>}
      <section className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full min-w-[1100px] text-sm">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50 text-left text-[11px] uppercase tracking-wide text-slate-500">
              {['Pozo / bomba', 'Finca', 'Suministro eléctrico', 'Lote / Sector', 'Potencia', 'Caudal'].map(h => <th key={h} rowSpan={2} scope="col" className="px-4 py-3">{h}</th>)}
              <th colSpan={3} scope="colgroup" className="px-4 py-3 text-emerald-800">Energía programada</th>
              <th colSpan={3} scope="colgroup" className="px-4 py-3 text-violet-700">Energía recomendada</th>
              <th rowSpan={2} scope="col" className="px-4 py-3">kWh/m³</th>
            </tr>
            <tr className="border-b border-slate-200 bg-slate-50 text-left text-[11px] uppercase tracking-wide text-slate-500">
              {['programada', 'recomendada'].flatMap(kind => ['Horas', 'kWh', 'Costo'].map(label => <th key={`${kind}-${label}`} scope="col" className="px-4 py-3">{label}</th>))}
            </tr>
          </thead>
          <tbody>
            {pumps.map(p => {
              const planned = scheduled.pumpStats.find(x => x.pump.id === p.id);
              const suggested = recommended.pumpStats.find(x => x.pump.id === p.id);
              return (
                <tr key={p.id} className="border-b border-slate-100">
                  <td className="px-4 py-3"><b className="text-charcoal">{p.name}</b></td>
                  <td className="px-4 py-3 text-slate-600">{p.farm || '—'}</td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-600">{p.energy_supply_number || '—'}</td>
                  <td className="px-4 py-3 text-slate-600">{[...new Set(turns.filter(g => g.well.pump_id === p.id).flatMap(g => g.members.map(m => m.row?.lot.name).filter(Boolean)))].join(' · ') || 'Sin lotes asignados en Monitoreo'}</td>
                  <td className="px-4 py-3 text-slate-600">{p.power_kw} kW</td>
                  <td className="px-4 py-3 text-slate-600">{p.flow_m3_h > 0 ? `${formatNumber(p.flow_m3_h)} m³/h` : 'Sin caudal cargado'}</td>
                  {[planned, suggested].map((stats, index) => <React.Fragment key={index}>
                    <td className="whitespace-nowrap px-4 py-3 text-slate-600">{formatHours(stats ? stats.hours : 0)}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-slate-600">{formatKwh(stats ? stats.kwh : 0)}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-slate-600">{formatCost(stats ? stats.cost : 0)}</td>
                  </React.Fragment>)}
                  <td className="px-4 py-3 text-slate-600">{p.flow_m3_h ? Math.round((p.power_kw / p.flow_m3_h) * 1000) / 1000 : '—'}</td>
                </tr>
              );
            })}
            {!pumps.length && <tr><td colSpan={13} className="px-4 py-8 text-center text-sm text-slate-400">Sin pozos ni bombas configurados. Cargalos en Configuración → Water & Energy.</td></tr>}
          </tbody>
        </table>
      </section>
      <p className="text-center text-xs text-slate-400">Consumo y costo estimados según potencia del pozo y tarifa configurada. La energía recomendada es adicional a la programada; cada turno se contabiliza una sola vez por pozo.</p>
    </div>
  );
}
