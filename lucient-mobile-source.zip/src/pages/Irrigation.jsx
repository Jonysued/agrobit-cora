import { useQuery } from '@tanstack/react-query';
import { monitoringService } from '@/services/irrigation/monitoringService';
import { assignedPrograms } from '@/services/irrigation/planning';
import React,{useState, lazy, Suspense} from 'react';
import { useSearchParams } from 'react-router-dom';
import { CalendarDays, Radio, Droplets, Gauge } from 'lucide-react';
const Sensors = lazy(() => import('@/pages/WaterEnergySoil'));
const SensorDetail = lazy(() => import('@/pages/WaterEnergySoilPoint'));
const WaterBalance = lazy(() => import('@/pages/WaterEnergy'));
const IrrigationMonitor = lazy(() => import('@/components/irrigation/monitor/IrrigationMonitor'));
const RegadorScanner = lazy(() => import('@/components/irrigation/monitor/RegadorScanner'));
const IrrigationRecommendations = lazy(() => import('@/components/irrigation/IrrigationRecommendations'));
import { useFarm } from '@/lib/FarmContext';
import { useAuth } from '@/lib/AuthContext';
import LoadingState from '@/components/LoadingState';
const ProgramForm = lazy(() => import('@/components/irrigation/ProgramForm'));
import { useIsMobile } from '@/hooks/use-mobile';
import { MobilePage, MobileAction } from '@/components/mobile/MobileUI';
import MobileWaterSummary from '@/components/mobile/MobileWaterSummary';
import { backend } from '@/api/backendClient';
import ProgramList from '@/components/irrigation/ProgramList';
import MonthlySchedule from '@/components/irrigation/MonthlySchedule';

export default function Irrigation(){
  const d=useFarm();
  const {user}=useAuth();
  const regador=user?.role==='regador';
  const mobile=useIsMobile();
  const [showForm,setShowForm]=useState(false);
  const [edit,setEdit]=useState(null);
  const [params, setParams] = useSearchParams();
  const tab = regador ? "monitoreo" : ["balance", "cronograma", "monitoreo", "recomendaciones", "sensores", ...(mobile ? ["resumen"] : [])].includes(params.get("tab")) ? params.get("tab") : mobile ? "resumen" : "balance";
  const devices=useQuery({queryKey:['irrigation-monitor', 'devices'],queryFn:()=>monitoringService.devices(),enabled:!!user&&!regador&&tab==='cronograma',staleTime:30000,refetchInterval:60000});
  const selectTab = value => { const next = new URLSearchParams(params); next.set("tab", value); next.delete("sonda"); next.delete("grafico"); next.delete("programar"); if (value !== "monitoreo") next.delete("equipo"); setParams(next); };
  const selectToken = token => { const next = new URLSearchParams(params); next.set("tab", "monitoreo"); if (token) next.set("equipo", token); else next.delete("equipo"); setParams(next); };
  if(regador && mobile && params.get('cuenta'))return <MobilePage title="Mi cuenta" back={{to:'/riego',label:'Monitoreo'}}><div className="mobile-card">{user?.full_name || user?.email}</div><MobileAction secondary onClick={()=>backend.auth.logout()}>Cerrar sesión</MobileAction></MobilePage>;
  if(regador)return <div className={mobile ? 'mobile-regador-page' : 'mx-auto max-w-xl p-5 lg:p-8'}><Suspense fallback={<LoadingState/>}><RegadorScanner token={params.get('equipo')} onSelectToken={selectToken}/></Suspense></div>;
  if(d.loading)return <LoadingState/>;
  const lots=d.Lot||[],designs=d.IrrigationDesign||[];
  const programs=assignedPrograms(d.IrrigationProgram||[],devices.data||[]).sort((a,b)=>(a.start_time||'').localeCompare(b.start_time||''));
  if(mobile){
    const titles={resumen:'Riego',balance:'Balance hídrico',cronograma:'Cronograma',monitoreo:'Monitoreo',recomendaciones:'Recomendaciones',sensores:'Sensores'};
    return <MobilePage><div className="mobile-water-tabs" role="tablist" aria-label="Secciones de riego">{[['resumen','Resumen'],['balance','Balance'],['cronograma','Cronograma'],['monitoreo','Monitoreo'],['recomendaciones','Recomendaciones'],['sensores','Sensores']].map(([value,label])=><button key={value} role="tab" id={`mobile-tab-${value}`} aria-selected={tab===value} aria-controls={`mobile-panel-${value}`} onClick={()=>{selectTab(value);setShowForm(false);}}>{label}</button>)}</div>{!params.get('sonda') && <h1>{titles[tab]}</h1>}<div role="tabpanel" id={`mobile-panel-${tab}`} aria-labelledby={`mobile-tab-${tab}`}><Suspense fallback={<LoadingState/>}>
      {tab==='resumen'?<MobileWaterSummary/>:tab==='balance'?<WaterBalance embedded/>:tab==='sensores'?(params.get('sonda')?<SensorDetail embedded probeIdProp={params.get('sonda')}/>:<Sensors embedded/>):tab==='recomendaciones'?<IrrigationRecommendations/>:tab==='monitoreo'?<IrrigationMonitor lots={lots} token={params.get('equipo')} onSelectToken={selectToken}/>:<>
        {devices.isError&&<p role="alert" className="mobile-note">No se pudieron cargar las asignaciones. <button onClick={()=>devices.refetch()}>Reintentar</button></p>}
        {showForm||edit||params.get('programar')?<><MobileAction secondary onClick={()=>{setShowForm(false);setEdit(null);selectTab('cronograma');}}>‹ Volver al cronograma</MobileAction><div className="mt-4"><ProgramForm devices={devices.data||[]} key={edit?.id||'new'} lots={lots} designs={designs} programs={programs} edit={edit} onSaved={async()=>{setEdit(null);setShowForm(false);selectTab('cronograma');await d.refetch();}} onCancel={()=>{setEdit(null);setShowForm(false);selectTab('cronograma');}}/></div></>:<><MobileAction onClick={()=>setShowForm(true)}>+ Programar riego</MobileAction><div className="mt-4"><ProgramList programs={programs} lots={lots} onEdit={p=>{setEdit(p);setShowForm(true);}} onChange={d.refetch}/></div><details className="mobile-detail-toggle"><summary>Calendario mensual</summary><MonthlySchedule programs={programs} lots={lots}/></details></>}
      </>}
    </Suspense></div></MobilePage>;
  }
  return <div className="mx-auto max-w-[1500px] p-5 lg:p-8">
    <div className="mb-7">
      <p className="text-sm font-bold uppercase tracking-[.18em] text-emerald-700">Manejo del recurso hídrico</p>
      <h1 className="text-3xl font-bold tracking-tight">Water</h1>
    </div>
    <div role="tablist" aria-label="Secciones de riego" className="mb-6 flex flex-wrap gap-2 border-b border-slate-200 pb-3">
      {[["balance", "Balance hídrico", Droplets], ["cronograma", "Cronograma de riegos", CalendarDays], ["monitoreo", "Monitoreo de riegos", Radio], ["recomendaciones", "Recomendaciones de riego", Droplets], ["sensores", "Sensores", Gauge]].filter(([value]) => !regador || value === 'monitoreo').map(([value, label, Icon]) => <button key={value} id={`tab-${value}`} role="tab" aria-selected={tab === value} aria-controls={`panel-${value}`} onClick={() => selectTab(value)} className={`flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-bold transition ${tab === value ? 'bg-emerald-900 text-white' : 'bg-white text-slate-600 hover:bg-slate-100'}`}><Icon size={17}/>{label}</button>)}
    </div>
    {tab === 'sensores' ? <div role="tabpanel" id="panel-sensores" aria-labelledby="tab-sensores"><Suspense fallback={<LoadingState/>}>{params.get('sonda') ? <SensorDetail embedded probeIdProp={params.get('sonda')} /> : <Sensors embedded />}</Suspense></div> : tab === 'balance' ? <div role="tabpanel" id="panel-balance" aria-labelledby="tab-balance"><Suspense fallback={<LoadingState/>}><WaterBalance embedded /></Suspense></div> : tab === 'recomendaciones' ? <div role="tabpanel" id="panel-recomendaciones" aria-labelledby="tab-recomendaciones"><Suspense fallback={<LoadingState/>}><IrrigationRecommendations /></Suspense></div> : tab === 'monitoreo' ? <div role="tabpanel" id="panel-monitoreo" aria-labelledby="tab-monitoreo"><Suspense fallback={<LoadingState/>}><IrrigationMonitor lots={lots} token={params.get('equipo')} onSelectToken={selectToken}/></Suspense></div> : <div role="tabpanel" id="panel-cronograma" aria-labelledby="tab-cronograma" className="grid gap-6 lg:grid-cols-[400px_1fr]">
      {devices.isError&&<p role="alert" className="lg:col-span-2 text-sm text-red-700">No se pudieron cargar las asignaciones de Monitoreo. <button onClick={()=>devices.refetch()} className="underline">Reintentar</button></p>}
      {!devices.isPending&&programs.some(p=>p._assignment_missing)&&<p role="alert" className="lg:col-span-2 text-sm text-amber-800">Hay programas sin turno válido en Monitoreo. Revisá sus asignaciones; no se atribuye esa agua a ningún lote.</p>}
      <ProgramForm devices={devices.data||[]} key={edit?.id||'new'} lots={lots} designs={designs} programs={programs} edit={edit}
        onSaved={async()=>{setEdit(null);await d.refetch();}}
        onCancel={()=>setEdit(null)}/>
      <div className="space-y-6">
        <MonthlySchedule programs={programs} lots={lots}/>
        <ProgramList programs={programs} lots={lots} onEdit={p=>{setEdit(p);window.scrollTo({top:0,behavior:'smooth'});}} onChange={d.refetch}/>
      </div>
    </div>}
  </div>;
}
