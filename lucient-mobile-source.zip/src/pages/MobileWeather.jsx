import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Sun } from 'lucide-react';
import { weatherService } from '@/services/waterEnergy/weatherService';
import { MobilePage, useMobileFarm, mobileNumber } from '@/components/mobile/MobileUI';
export default function MobileWeather() {
  const { farm } = useMobileFarm();
  const farms = useQuery({ queryKey: ['weather-farms'], queryFn: () => weatherService.getFarms(), staleTime: 300000 });
  const selected = farms.data?.find(f => f.name === farm) || farms.data?.find(f => f.name === 'Las 500') || farms.data?.[0];
  const weather = useQuery({ queryKey: ['mobile-weather', selected?.id], queryFn: () => weatherService.getCombinedWeather(selected), enabled: !!selected, staleTime: 120000, refetchInterval: 300000 });
  const data = weather.data, now = data?.current;
  return <MobilePage title="Pronóstico" subtitle={data?.station?.name || selected?.name || 'Clima de la finca'} back={{ to: '/dashboard', label: 'Inicio' }}>
    {(farms.isError || weather.isError) && <p className="mobile-note" role="alert">No se pudo actualizar el clima. <button onClick={() => { void farms.refetch(); void weather.refetch(); }}>Reintentar</button></p>}
    <div className="mobile-card"><div className="mobile-pair"><div className="mobile-value">{now?.temperature_c != null ? `${mobileNumber(now.temperature_c)}°` : (farms.isPending || (selected && weather.isPending)) ? 'Cargando…' : 'Sin lectura'}</div><Sun size={22} color="#a58035" /></div>{now && <p className="mobile-muted">Dato observado · {new Date(now.timestamp).toLocaleString('es-AR', { timeZone: 'America/Argentina/Buenos_Aires' })}</p>}<div className="mobile-split">{(data?.forecast || []).slice(0, 4).map(day => <div key={day.date} className="mobile-card" style={{ margin: '8px 0', padding: 12 }}><p className="mobile-kicker">{new Date(day.date + 'T12:00:00').toLocaleDateString('es-AR', { weekday: 'short', day: 'numeric' })}</p><b>{mobileNumber(day.temperature_max_c)}° / {mobileNumber(day.temperature_min_c)}°</b><p className="mobile-muted">{mobileNumber(day.rainfall_mm)} mm</p></div>)}</div></div>
    <h2>Detalle meteorológico</h2><div className="mobile-card">{[['Viento', now?.wind_speed_kmh, 'km/h'], ['Humedad relativa', now?.relative_humidity_percent, '%'], ['Lluvia observada', now?.rainfall_mm, 'mm'], ['ET0 del día', now?.et_day_mm ?? now?.eto_mm, 'mm']].map(([label,value,unit]) => <div className="mobile-state-row" key={label}><span>{label}</span><b>{value == null ? 'Sin lectura' : `${mobileNumber(value)} ${unit}`}</b></div>)}</div>
    <details className="mobile-detail-toggle"><summary>Pronóstico de 15 días</summary>{(data?.forecast || []).map(day => <div className="mobile-state-row" key={day.date}><span>{new Date(day.date + 'T12:00:00').toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })}</span><b>{mobileNumber(day.temperature_max_c)}° / {mobileNumber(day.temperature_min_c)}° · {mobileNumber(day.rainfall_mm)} mm</b></div>)}<p className="mobile-muted">Fuente: {data?.forecastSource || 'Sin información'}</p></details>
  </MobilePage>;
}
