begin;
select set_config('request.jwt.claim.sub',(select id::text from public.profiles where role='admin' limit 1),true);
insert into public.irrigation_devices(kind,name,farm) values('well','__DELETE_EVENT_TEST__','__TEST__');
set local role authenticated;
do $$
declare d uuid; a public.irrigation_device_events; b public.irrigation_device_events; denied boolean:=false; admin_id text:=auth.uid()::text;
begin
 select id into d from public.irrigation_devices where name='__DELETE_EVENT_TEST__';
 a:=public.record_irrigation_action(d,true,gen_random_uuid());
 b:=public.record_irrigation_action(d,false,gen_random_uuid());
 perform set_config('request.jwt.claim.sub',gen_random_uuid()::text,true);
 begin perform public.delete_irrigation_action(b.id,'Prueba sin permisos'); exception when raise_exception then denied:=true; end;
 if not denied then raise exception 'Non-admin deletion allowed'; end if;
 perform set_config('request.jwt.claim.sub',admin_id,true);
 perform public.delete_irrigation_action(b.id,'Registro de prueba duplicado');
 if exists(select 1 from public.irrigation_device_events where id=b.id) then raise exception 'Deleted event still visible'; end if;
 if (select current_active from public.irrigation_devices where id=d) is distinct from false then raise exception 'Well reopened'; end if;
 if exists(select 1 from public.irrigation_device_sessions(d,now()-interval '1 hour')) then raise exception 'Deleted session still counted'; end if;
 denied:=false;
 begin perform public.correct_irrigation_action(b.id,false,now(),'Corrección eliminada'); exception when raise_exception then denied:=true; end;
 if not denied then raise exception 'Deleted event was corrected'; end if;
 perform public.delete_irrigation_action(b.id,'Reintento de eliminación');
 perform public.delete_irrigation_action(a.id,'Último registro de prueba');
 if (select current_active from public.irrigation_devices where id=d) is distinct from false then raise exception 'Empty closed history reopened'; end if;
 if exists(select 1 from public.irrigation_device_sessions(d,now()-interval '1 hour')) then raise exception 'Deleted irrigation still counted'; end if;
 if (public.record_irrigation_action(d,true,a.request_id)).id<>a.id then raise exception 'Retry lost idempotency'; end if;
end $$;
reset role;
do $$ begin
 if (select count(*) from public.irrigation_device_events e join public.irrigation_devices d on d.id=e.device_id where d.name='__DELETE_EVENT_TEST__' and e.deleted_at is not null and e.deleted_by is not null and length(e.deletion_reason)>5)<>2 then raise exception 'Deletion audit missing'; end if;
end $$;
select 'PASS: admin-only deletion, hidden events, rebuilt state and sessions, correction denial, retries and audit' as result;
rollback;
