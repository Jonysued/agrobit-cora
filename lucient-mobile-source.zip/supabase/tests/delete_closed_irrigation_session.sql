begin;
select set_config('request.jwt.claim.sub',(select id::text from public.profiles where role='admin' limit 1),true);
insert into public.irrigation_devices(kind,name,farm) values('well','__DELETE_CLOSED_SESSION_TEST__','__TEST__');
set local role authenticated;
do $$
declare d uuid; a public.irrigation_device_events; b public.irrigation_device_events; c public.irrigation_device_events; f public.irrigation_device_events; denied boolean:=false;
begin
 select id into d from public.irrigation_devices where name='__DELETE_CLOSED_SESSION_TEST__';
 a:=public.record_irrigation_action(d,true,gen_random_uuid());
 b:=public.record_irrigation_action(d,false,gen_random_uuid());
 c:=public.record_irrigation_action(d,true,gen_random_uuid());
 perform public.delete_irrigation_action(b.id,'Prueba sesión anterior');
 if exists(select 1 from public.irrigation_device_events where id in (a.id,b.id)) then raise exception 'Closed session still visible'; end if;
 if not(select current_active from public.irrigation_devices where id=d) then raise exception 'Later active session changed'; end if;
 if (select count(*) from public.irrigation_device_sessions(d,now()-interval '1 hour'))<>1 then raise exception 'Historical session still counted'; end if;
 f:=public.record_irrigation_action(d,false,gen_random_uuid());
 perform public.delete_irrigation_action(f.id,'Prueba último apagado');
 if (select current_active from public.irrigation_devices where id=d) is distinct from false then raise exception 'Deleted stop reopened well'; end if;
 if exists(select 1 from public.irrigation_device_events where device_id=d) then raise exception 'Opening not removed'; end if;
 if exists(select 1 from public.irrigation_device_sessions(d,now()-interval '1 hour')) then raise exception 'Deleted sessions still counted'; end if;
 perform public.delete_irrigation_action(f.id,'Reintento idempotente');
 perform set_config('request.jwt.claim.sub',gen_random_uuid()::text,true);
 begin perform public.delete_irrigation_action(f.id,'No autorizado'); exception when raise_exception then denied:=true; end;
 if not denied then raise exception 'Nonadmin permitted'; end if;
end $$;
reset role;
do $$ begin
 if(select count(*) from public.irrigation_device_events e join public.irrigation_devices d on d.id=e.device_id where d.name='__DELETE_CLOSED_SESSION_TEST__' and e.deleted_at is not null and e.deleted_by is not null)<>4 then raise exception 'Audit incomplete'; end if;
end $$;
select 'PASS: closed session removed, well stays off, later sessions preserved, audit and admin permissions verified' as verification;
rollback;
