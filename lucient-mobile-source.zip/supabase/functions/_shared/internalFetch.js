// Only retry an authentication rejection known to happen before execution.
export function createInternalFetch(fetcher = fetch, pause = ms => new Promise(resolve => setTimeout(resolve, ms))) {
  return async (input, init) => {
    const request = new Request(input, init);
    const delays = [250, 750, 1500];
    for (let attempt = 0; ; attempt++) {
      const response = await fetcher(request.clone());
      if (response.status !== 401 || attempt >= delays.length) return response;
      let message;
      try { message = (await response.clone().json())?.message; } catch { return response; }
      if (message !== 'JWT issued at future') return response;
      await response.body?.cancel();
      await pause(delays[attempt]);
    }
  };
}
