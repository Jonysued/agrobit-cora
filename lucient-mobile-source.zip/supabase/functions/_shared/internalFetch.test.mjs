import test from 'node:test';
import assert from 'node:assert/strict';
import { createInternalFetch } from './internalFetch.js';

const rejected = message => Response.json({ message }, { status: 401 });
test('retries a transient future JWT before a write, preserving its body', async () => {
  const bodies = [], waits = [];
  const fetcher = createInternalFetch(async request => {
    bodies.push(await request.text());
    return bodies.length < 3 ? rejected('JWT issued at future') : Response.json({ id: 'saved' });
  }, async ms => { waits.push(ms); });
  const response = await fetcher('https://database.example/rest/v1/readings', { method: 'POST', body: '{"value":12}' });
  assert.deepEqual(await response.json(), { id: 'saved' });
  assert.deepEqual(bodies, Array(3).fill('{"value":12}'));
  assert.deepEqual(waits, [250, 750]);
});
test('never replays successful writes, other auth errors, or server failures', async () => {
  for (const response of [Response.json({ id: 'saved' }), rejected('JWT expired'), Response.json({ message: 'JWT issued at future' }, { status: 500 })]) {
    let calls = 0;
    const fetcher = createInternalFetch(async () => { calls++; return response; }, async () => assert.fail('unexpected retry'));
    assert.equal(await fetcher('https://database.example'), response);
    assert.equal(calls, 1);
  }
});
test('stops after four rejected requests and preserves the final error', async () => {
  let calls = 0;
  const fetcher = createInternalFetch(async () => { calls++; return rejected('JWT issued at future'); }, async () => {});
  const response = await fetcher('https://database.example');
  assert.equal(calls, 4);
  assert.equal(response.status, 401);
  assert.equal((await response.json()).message, 'JWT issued at future');
});
test('does not replay an uncertain write after a network error', async () => {
  let calls = 0;
  const fetcher = createInternalFetch(async () => { calls++; throw new TypeError('network failure'); }, async () => assert.fail('unexpected retry'));
  await assert.rejects(fetcher('https://database.example', { method: 'POST', body: '{}' }), /network failure/);
  assert.equal(calls, 1);
});
