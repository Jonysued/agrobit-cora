import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeDavisCurrent} from './weatherAdapters.ts';
test('response generation and health timestamps cannot refresh older weather',()=>{
 const d=normalizeDavisCurrent({generated_at:200000,sensors:[
  {data:[{ts:100000,temp_out:70,rain_day_mm:27.2}]},
  {data:[{ts:199999,battery_voltage:90}]}]});
 assert.equal(d.timestamp,new Date(100000000).toISOString());
 assert.equal(d.rainfall_daily_mm,27.2);
});
test('response without a weather sensor timestamp is not a new measurement',()=>{
 assert.equal(normalizeDavisCurrent({generated_at:200000,sensors:[{data:[{rain_day_mm:27.2}]}]}).timestamp,null);
});
test('old rain counter from another sensor cannot accompany fresh outdoor weather',()=>{
 const d=normalizeDavisCurrent({sensors:[{data:[{ts:200000,temp:70}]},{data:[{ts:100000,rain_day_mm:27.2}]}]});
 assert.equal(d.rainfall_daily_mm,null);
});
