import test from 'node:test';
import assert from 'node:assert/strict';
import { syncWeatherStation } from './weatherSync.ts';
const rows=[
 {source:'davis',timestamp:'2026-10-14T03:00:04Z',rainfall_mm:27.2},
 {source:'davis',timestamp:'2026-10-13T10:00:04Z',rainfall_mm:25},
 {source:'davis',timestamp:'2026-10-13T03:00:05Z',rainfall_mm:2.2},
 {source:'davis',timestamp:'2026-10-13T02:00:04Z',rainfall_mm:2.2}];
async function run(timestamp,counter,recent=rows){
 const oldFetch=globalThis.fetch,oldDeno=globalThis.Deno;
 let saved;
 globalThis.Deno={env:{get:()=> 'test-only'}};
 globalThis.fetch=async()=>Response.json({generated_at:Date.parse(timestamp)/1000,
  sensors:[{data:[{ts:Date.parse(timestamp)/1000,rainfall_daily_mm:counter,et_day:0}]}]});
 const client={entities:{WeatherStation:{update:async()=>{}},WeatherObservation:{filter:async()=>recent,bulkCreate:async payload=>{saved=payload;}}}};
 try{await syncWeatherStation(client,{id:'garita',provider:'davis',external_station_id:'fixture',farm_ids:['a','b']});return saved;}
 finally{globalThis.fetch=oldFetch;globalThis.Deno=oldDeno;}
}
test('new midnight ingestion records no carried daily rain',async()=>{
 const saved=await run('2026-10-14T03:00:04Z',27.2,rows.slice(1));
 assert.equal(saved[0].rainfall_mm,0);
 assert.equal(saved[0].quality_status,'day_boundary_increment');
});
test('legacy phantom rain cannot suppress a later real increment',async()=>{
 const saved=await run('2026-10-14T03:30:04Z',3);
 assert.equal(saved[0].rainfall_mm,3);
 assert.equal(saved[1].rainfall_mm,3);
});
test('midnight preserves late previous-day rain once',async()=>{
 const saved=await run('2026-10-14T03:00:04Z',28.2,rows.slice(1));
 assert.equal(saved[0].rainfall_mm,1);
});
test('unchanged midnight carry is not repeated by a later daytime sync',async()=>{
 const saved=await run('2026-10-14T15:30:04Z',27.2);
 assert.equal(saved[0].rainfall_mm,0);
 assert.equal(saved[0].rainfall_counter_mm,27.2);
});
test('persisted provider counter adds only the increment and can reset on a new day',async()=>{
 const old={source:'davis',timestamp:'2026-10-14T15:30:04Z',rainfall_mm:0,rainfall_counter_mm:27.2};
 assert.equal((await run('2026-10-14T16:00:04Z',28.2,[old]))[0].rainfall_mm,1);
 assert.equal((await run('2026-10-15T04:00:04Z',2,[old]))[0].rainfall_mm,2);
 assert.equal((await run('2026-10-15T03:00:04Z',2,[old]))[0].quality_status,'ok');
 assert.equal((await run('2026-10-15T03:00:04Z',2,[old]))[0].rainfall_mm,2);
});
test('reset after a carried midnight counter preserves the first real rain',async()=>{
 const carry={source:'davis',timestamp:'2026-10-14T03:00:04Z',rainfall_mm:0,
  rainfall_counter_mm:27.2,quality_status:'day_boundary_increment'};
 assert.equal((await run('2026-10-14T03:30:04Z',3,[carry]))[0].rainfall_mm,3);
});
test('a new day with more rain than yesterday retains its whole fresh daily counter',async()=>{
 const old={source:'davis',timestamp:'2026-10-14T15:30:04Z',rainfall_mm:5,rainfall_counter_mm:5};
 assert.equal((await run('2026-10-15T15:00:04Z',8,[old]))[0].rainfall_mm,8);
});
