-- Logical deletion preserves request idempotency and the original audit trail.
alter table public.irrigation_device_events
  add column deleted_at timestamptz,
  add column deleted_by uuid references auth.users(id) on delete set null,
  add column deletion_reason text;
create policy irrigation_events_not_deleted on public.irrigation_device_events
  as restrictive for select to authenticated using (deleted_at is null);

create function private.delete_irrigation_action(p_event_id uuid,p_reason text)
returns void language plpgsql security definer set search_path='' as $$
declare ev public.irrigation_device_events; last_ev public.irrigation_device_events;
begin
  if auth.uid() is null or not public.is_admin() then
    raise exception 'Solo un administrador puede eliminar registros.';
  end if;
  if length(trim(coalesce(p_reason,'')))<5 then raise exception 'Ingresá el motivo de la eliminación.'; end if;
  perform pg_advisory_xact_lock(60930202515);
  select * into ev from public.irrigation_device_events where id=p_event_id for update;
  if not found then raise exception 'Registro no encontrado.'; end if;
  if ev.deleted_at is not null then return; end if;
  perform 1 from public.irrigation_devices where id=ev.device_id for update;
  update public.irrigation_device_events
    set deleted_at=clock_timestamp(),deleted_by=auth.uid(),deletion_reason=trim(p_reason)
    where id=ev.id;
  select * into last_ev from public.irrigation_device_events
    where device_id=ev.device_id and deleted_at is null
    order by occurred_at desc,sequence desc limit 1;
  update public.irrigation_devices set current_active=last_ev.active,state_since=last_ev.occurred_at
    where id=ev.device_id;
end; $$;
revoke all on function private.delete_irrigation_action(uuid,text) from public,anon;
grant execute on function private.delete_irrigation_action(uuid,text) to authenticated;
create function public.delete_irrigation_action(p_event_id uuid,p_reason text)
returns void language sql security invoker set search_path='' as $$
  select private.delete_irrigation_action(p_event_id,p_reason);
$$;
revoke all on function public.delete_irrigation_action(uuid,text) from public,anon;
grant execute on function public.delete_irrigation_action(uuid,text) to authenticated;

-- Corrections must not revive deleted entries or use them as the latest state.
do $$
declare definition text;
begin
  definition:=pg_get_functiondef('public.correct_irrigation_action(uuid,boolean,timestamptz,text)'::regprocedure);
  if position('where id=p_event_id for update' in definition)=0
    or position('where device_id=ev.device_id order by' in definition)=0 then
    raise exception 'Unexpected correction function; review before migration.';
  end if;
  definition:=replace(definition,'where id=p_event_id for update','where id=p_event_id and deleted_at is null for update');
  definition:=replace(definition,'where device_id=ev.device_id order by','where device_id=ev.device_id and deleted_at is null order by');
  execute definition;
end $$;
