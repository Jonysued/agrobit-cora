-- Retain the original provider counter alongside its derived interval.
-- Existing raw observations and access policies remain intact.
alter table public.weather_observations
  add column if not exists rainfall_counter_mm double precision;
comment on column public.weather_observations.rainfall_counter_mm is
  'Original provider daily rain counter in mm; rainfall_mm is the derived interval. Null for legacy rows.';
