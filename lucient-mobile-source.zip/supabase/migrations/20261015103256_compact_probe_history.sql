-- One bounded, compact response; every measurement is retained unchanged.
-- SECURITY INVOKER preserves the caller's existing table privileges and RLS.
create or replace function public.probe_readings_range(
  p_probe_id text, p_from timestamptz, p_to timestamptz
) returns jsonb
language plpgsql stable security invoker set search_path = ''
as $$
declare result jsonb;
begin
  if p_probe_id is null or p_from is null or p_to is null
     or p_to < p_from or p_to - p_from > interval '95 days' then
    raise exception 'Invalid probe history range' using errcode = '22023';
  end if;
  select jsonb_build_object('version', 1, 'rows',
    coalesce(jsonb_agg(jsonb_build_array(
      r.id, r.probe_channel_id, r.timestamp, r.value,
      r.depth_cm, r.unit, r.source, r.quality_status
    ) order by r.timestamp, r.id), '[]'::jsonb))
  into result
  from public.sensor_readings r
  where r.probe_id = p_probe_id and r.timestamp >= p_from and r.timestamp <= p_to;
  return result;
end;
$$;
revoke all on function public.probe_readings_range(text,timestamptz,timestamptz) from public, anon;
grant execute on function public.probe_readings_range(text,timestamptz,timestamptz) to authenticated;
