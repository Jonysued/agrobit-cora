-- Every self-registered account starts with the QR-only irrigation role.
-- Existing accounts are intentionally not updated.
alter table public.profiles alter column role set default 'regador';

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1)),
    'regador'
  );
  return new;
end;
$$;
