-- The signup trigger is internal; clients must not invoke it as an RPC.
revoke execute on function public.handle_new_user() from public, anon, authenticated;
