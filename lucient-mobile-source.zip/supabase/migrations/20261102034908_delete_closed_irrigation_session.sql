-- Deleting a stop also removes its associated opening(s), never reopening it.
create or replace function private.delete_irrigation_action(p_event_id uuid,p_reason text)
returns void language plpgsql security definer set search_path='' as $$
declare
  ev public.irrigation_device_events;
  last_ev public.irrigation_device_events;
  previous_stop public.irrigation_device_events;
begin
  if auth.uid() is null or not public.is_admin() then
    raise exception 'Solo un administrador puede eliminar registros.';
  end if;
  if length(trim(coalesce(p_reason,'')))<5 then raise exception 'Ingresá el motivo de la eliminación.'; end if;
  perform pg_advisory_xact_lock(60930202515);
  select * into ev from public.irrigation_device_events where id=p_event_id for update;
  if not found then raise exception 'Registro no encontrado.'; end if;
  if ev.deleted_at is not null then return; end if;
  perform 1 from public.irrigation_devices where id=ev.device_id for update;
  if not ev.active then
    select * into previous_stop from public.irrigation_device_events
      where device_id=ev.device_id and deleted_at is null and not active
        and (occurred_at,sequence)<(ev.occurred_at,ev.sequence)
      order by occurred_at desc,sequence desc limit 1;
    update public.irrigation_device_events
      set deleted_at=clock_timestamp(),deleted_by=auth.uid(),
          deletion_reason=trim(p_reason) || ' · Encendido asociado al apagado eliminado'
      where device_id=ev.device_id and deleted_at is null and active
        and (occurred_at,sequence)<(ev.occurred_at,ev.sequence)
        and (previous_stop.id is null or (occurred_at,sequence)>(previous_stop.occurred_at,previous_stop.sequence));
  end if;
  update public.irrigation_device_events
    set deleted_at=clock_timestamp(),deleted_by=auth.uid(),deletion_reason=trim(p_reason)
    where id=ev.id;
  select * into last_ev from public.irrigation_device_events
    where device_id=ev.device_id and deleted_at is null
    order by occurred_at desc,sequence desc limit 1;
  update public.irrigation_devices
    set current_active=case when last_ev.id is not null then last_ev.active when not ev.active then false else null end,
        state_since=case when last_ev.id is not null then last_ev.occurred_at when not ev.active then ev.occurred_at else null end
    where id=ev.device_id;
end; $$;
